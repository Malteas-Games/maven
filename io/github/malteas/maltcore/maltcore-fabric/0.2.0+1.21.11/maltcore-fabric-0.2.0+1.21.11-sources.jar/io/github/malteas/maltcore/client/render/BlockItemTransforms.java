package io.github.malteas.maltcore.client.render;

import net.minecraft.class_804;
import net.minecraft.class_809;
import org.joml.Vector3f;

/**
 * The standard block display transforms from minecraft:block/block
 * (translations are stored normalized, i.e. divided by 16). Shared by the
 * modern item model and the old-era (&lt;1.21.5) baked model.
 */
public final class BlockItemTransforms {

    private BlockItemTransforms() {}

    public static class_809 blockTransforms() {
        class_804 thirdPerson = new class_804(
                new Vector3f(75f, 45f, 0f), new Vector3f(0f, 2.5f / 16f, 0f), new Vector3f(0.375f));
        class_804 firstPersonRight = new class_804(
                new Vector3f(0f, 45f, 0f), new Vector3f(), new Vector3f(0.4f));
        class_804 firstPersonLeft = new class_804(
                new Vector3f(0f, 225f, 0f), new Vector3f(), new Vector3f(0.4f));
        class_804 gui = new class_804(
                new Vector3f(30f, 225f, 0f), new Vector3f(), new Vector3f(0.625f));
        class_804 ground = new class_804(
                new Vector3f(), new Vector3f(0f, 3f / 16f, 0f), new Vector3f(0.25f));
        class_804 fixed = new class_804(
                new Vector3f(), new Vector3f(), new Vector3f(0.5f));
        return new class_809(
                thirdPerson, thirdPerson,
                firstPersonLeft, firstPersonRight,
                class_804.field_4284,
                gui, ground, fixed
                // fixedFromBottom was added in 1.21.9.
                //? if >=1.21.9
                , fixed
        );
    }
}
