package io.github.malteas.maltcore.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Supplier;

/**
 * Generic JSON-backed config holder. Subclasses (or callers) provide a data
 * record/POJO type T plus a defaults supplier; this class handles file I/O.
 *
 * Typical use:
 * <pre>
 *     private static final ConfigPersistence&lt;Data&gt; CONFIG =
 *         new ConfigPersistence&lt;&gt;("mymod.json", Data.class, Data::new);
 *
 *     public static void init(Path configDir) { CONFIG.init(configDir); }
 *     public static Data data() { return CONFIG.get(); }
 *     public static void save() { CONFIG.save(); }
 * </pre>
 */
public class ConfigPersistence<T> {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final String fileName;
    private final Class<T> dataType;
    private final Supplier<T> defaults;
    private Path configPath;
    private T data;

    public ConfigPersistence(String fileName, Class<T> dataType, Supplier<T> defaults) {
        this.fileName = fileName;
        this.dataType = dataType;
        this.defaults = defaults;
        this.data = defaults.get();
    }

    /** Resolve config path under {@code configDir} and load existing data if present. */
    public void init(Path configDir) {
        this.configPath = configDir.resolve(fileName);
        load();
    }

    public T get() {
        return data;
    }

    /** Reset to defaults (does not save). */
    public void reset() {
        this.data = defaults.get();
    }

    /** Persist to disk. Returns false if init() has not been called. */
    public boolean save() throws IOException {
        if (configPath == null) return false;
        Files.createDirectories(configPath.getParent());
        Files.writeString(configPath, GSON.toJson(data));
        return true;
    }

    /** Load from disk. Keeps current data on missing/invalid file. */
    public void load() {
        if (configPath == null || !Files.exists(configPath)) return;
        try {
            String json = Files.readString(configPath);
            T loaded = GSON.fromJson(json, dataType);
            if (loaded != null) {
                data = loaded;
            }
        } catch (Exception ignored) {
            // keep current data on parse failure
        }
    }
}
