package io.github.malteas.maltcore.client;

import net.minecraft.class_304;
import net.minecraft.class_310;

/**
 * Detects tap (short press) vs hold (long press) on a KeyMapping.
 * Call {@link #tick()} every client tick. Ignores presses while a screen is open.
 */
public class LongPressAction {
    private final class_304 key;
    private final int holdThreshold;
    private final Runnable onShortPress;
    private final Runnable onLongPress;

    private boolean wasDown = false;
    private int holdTicks = 0;

    public LongPressAction(class_304 key, int holdThreshold, Runnable onShortPress, Runnable onLongPress) {
        this.key = key;
        this.holdThreshold = holdThreshold;
        this.onShortPress = onShortPress;
        this.onLongPress = onLongPress;
    }

    public void tick() {
        class_310 mc = class_310.method_1551();

        while (key.method_1436()) {}

        boolean down = mc.field_1755 == null && key.method_1434();

        if (down) {
            holdTicks++;
            if (holdTicks == holdThreshold) {
                onLongPress.run();
            }
        } else {
            if (wasDown && holdTicks > 0 && holdTicks < holdThreshold && mc.field_1755 == null) {
                onShortPress.run();
            }
            holdTicks = 0;
        }

        wasDown = down;
    }
}
