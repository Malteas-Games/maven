package io.github.malteas.maltcore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class MaltCore {
    public static final String MOD_ID = "maltcore";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private MaltCore() {}
}
