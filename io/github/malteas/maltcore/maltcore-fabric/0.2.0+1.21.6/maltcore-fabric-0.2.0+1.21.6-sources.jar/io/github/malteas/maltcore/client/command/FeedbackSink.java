package io.github.malteas.maltcore.client.command;

import net.minecraft.class_2561;

/** Loader-neutral command feedback: success and error channels for any source type. */
public interface FeedbackSink<S> {
    void success(S source, class_2561 message);

    void error(S source, class_2561 message);
}
