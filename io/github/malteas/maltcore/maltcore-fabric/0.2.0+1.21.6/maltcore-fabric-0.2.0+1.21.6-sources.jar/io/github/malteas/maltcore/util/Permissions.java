package io.github.malteas.maltcore.util;

import net.minecraft.class_1657;

/** Version-safe permission checks (the permission API was reworked in 1.21.11). */
public final class Permissions {
    private Permissions() {}

    /** True when the player may edit the world beyond survival play: op (cheats) or creative mode. */
    public static boolean canEditWorld(class_1657 player) {
        //? if >=1.21.11 {
        /*boolean op = player.permissions().hasPermission(
                net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER);
        *///?} else {
        boolean op = player.method_64475(2);
        //?}
        return op || player.method_31549().field_7477;
    }
}
