package io.github.malteas.maltcore.util;

import net.minecraft.class_1657;
import net.minecraft.class_2350;

/**
 * Camera-relative direction math — converts (right, forward, up) inputs
 * into world-space (dx, dy, dz) offsets based on the player's yaw.
 */
public record CameraRelativeOffset(int dx, int dy, int dz) {
    public static CameraRelativeOffset resolve(class_1657 player, int right, int forward, int up) {
        class_2350 forwardDir = class_2350.method_10150(player.method_36454());
        class_2350 rightDir = forwardDir.method_10170();

        int dx = forwardDir.method_10148() * forward + rightDir.method_10148() * right;
        int dy = up;
        int dz = forwardDir.method_10165() * forward + rightDir.method_10165() * right;

        return new CameraRelativeOffset(dx, dy, dz);
    }
}
