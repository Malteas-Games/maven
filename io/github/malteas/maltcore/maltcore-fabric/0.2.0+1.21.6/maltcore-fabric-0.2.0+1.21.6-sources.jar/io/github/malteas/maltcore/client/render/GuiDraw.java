package io.github.malteas.maltcore.client.render;

import net.minecraft.class_10799;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Version-safe {@link class_332} drawing helpers. GuiGraphics changed shape
 * repeatedly across the supported range (1.21.1 plain blits, 1.21.2 RenderType
 * function, 1.21.6 RenderPipelines + 2D pose stack, 26.1 extractor rename);
 * every fork lives here so mods draw through one stable API.
 */
public final class GuiDraw {
    private GuiDraw() {}

    /**
     * Blit a texture region at its natural size.
     * Note: on <=1.21.4 the raw blit does not set up alpha blending — callers
     * drawing translucent textures there wrap the call in RenderSystem blend.
     */
    public static void blit(class_332 g, class_2960 tex, int x, int y,
                            float u, float v, int w, int h, int texW, int texH) {
        //? if >=1.21.6 {
        g.method_25290(class_10799.field_56883, tex, x, y, u, v, w, h, texW, texH);
        //?} elif >=1.21.2 {
        /*g.blit(net.minecraft.client.renderer.RenderType::guiTextured, tex, x, y, u, v, w, h, texW, texH);*/
        //?} else {
        /*g.blit(tex, x, y, u, v, w, h, texW, texH);*/
        //?}
    }

    /** Blit a texture region stretched to an arbitrary destination size (blend note as on {@link #blit}). */
    public static void region(class_332 g, class_2960 tex, int dx, int dy, int dw, int dh,
                              float u, float v, int uw, int vh, int texW, int texH) {
        if (dw <= 0 || dh <= 0) return;
        //? if >=1.21.6 {
        g.method_25302(class_10799.field_56883, tex, dx, dy, u, v, dw, dh, uw, vh, texW, texH);
        //?} elif >=1.21.2 {
        /*g.blit(net.minecraft.client.renderer.RenderType::guiTextured, tex, dx, dy, u, v, dw, dh, uw, vh, texW, texH);*/
        //?} else {
        /*g.blit(tex, dx, dy, dw, dh, u, v, uw, vh, texW, texH);*/
        //?}
    }

    /** Draw a whole texture scaled to w×h. */
    public static void texture(class_332 g, class_2960 tex, int x, int y, int w, int h) {
        region(g, tex, x, y, w, h, 0f, 0f, w, h, w, h);
    }

    public static void blitSprite(class_332 g, class_2960 sprite, int x, int y, int w, int h) {
        //? if >=1.21.6 {
        g.method_52706(class_10799.field_56883, sprite, x, y, w, h);
        //?} elif >=1.21.2 {
        /*g.blitSprite(net.minecraft.client.renderer.RenderType::guiTextured, sprite, x, y, w, h);*/
        //?} else {
        /*g.blitSprite(sprite, x, y, w, h);*/
        //?}
    }

    /**
     * Blit a square texture centered on (cx, cy), rotated and scaled.
     * angle is in radians; textures pointing "up" rotate clockwise.
     */
    public static void rotatedBlit(class_332 g, class_2960 tex, float cx, float cy,
                                   int size, float angleRadians, float scale) {
        //? if >=1.21.6 {
        g.method_51448().pushMatrix();
        g.method_51448().translate(cx, cy);
        g.method_51448().scale(scale, scale);
        g.method_51448().rotate(angleRadians);
        g.method_51448().translate(-size / 2f, -size / 2f);
        //? if >=26.1 {
        /*g.blit(tex, 0, 0, size, size, 0f, 0f, 1f, 1f);
        *///?} else {
        g.method_25291(class_10799.field_56883, tex, 0, 0, 0f, 0f, size, size, size, size, -1);
        //?}
        g.method_51448().popMatrix();
        //?} else {
        /*g.pose().pushMatrix();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(scale, scale, 1);
        g.pose().mulPose(com.mojang.math.Axis.ZP.rotation(angleRadians));
        g.pose().translate(-size / 2f, -size / 2f, 0);
        //? if <=1.21.4 {
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
        //?}
        //? if <=1.21.1 {
        g.blit(tex, 0, 0, 0, 0, size, size, size, size);
        //?} else {
        g.blit(net.minecraft.client.renderer.RenderType::guiTextured, tex, 0, 0, 0, 0, size, size, size, size);
        //?}
        //? if <=1.21.4 {
        com.mojang.blaze3d.systems.RenderSystem.disableBlend();
        //?}
        g.pose().popMatrix();
        *///?}
    }

    // --- Text ---

    public static void text(class_332 g, class_327 font, String s, int x, int y, int color) {
        g.method_25303(font, s, x, y, color);
    }

    public static void text(class_332 g, class_327 font, String s, int x, int y, int color, boolean shadow) {
        g.method_51433(font, s, x, y, color, shadow);
    }

    public static void text(class_332 g, class_327 font, class_2561 c, int x, int y, int color) {
        g.method_27535(font, c, x, y, color);
    }

    public static void centeredText(class_332 g, class_327 font, String s, int x, int y, int color) {
        g.method_25300(font, s, x, y, color);
    }

    public static void centeredText(class_332 g, class_327 font, class_2561 c, int x, int y, int color) {
        g.method_27534(font, c, x, y, color);
    }

    /** Right-align text against a screen edge with the given padding. */
    public static void rightAlignedText(class_332 g, class_327 font, String s,
                                        int rightEdge, int y, int padding, int color) {
        text(g, font, s, rightEdge - font.method_1727(s) - padding, y, color);
    }

    /** Draw text scaled around its own anchor point. */
    public static void scaledText(class_332 g, class_327 font, class_2561 c,
                                  int x, int y, float scale, int color) {
        g.method_51448().pushMatrix();
        //? if >=1.21.6 {
        g.method_51448().scale(scale, scale);
        //?} else {
        /*g.pose().scale(scale, scale, 1f);*/
        //?}
        g.method_27535(font, c, (int) (x / scale), (int) (y / scale), color);
        g.method_51448().popMatrix();
    }

    /** Draw centered text scaled around its own anchor point. */
    public static void scaledCenteredText(class_332 g, class_327 font, class_2561 c,
                                          int cx, int y, float scale, int color) {
        g.method_51448().pushMatrix();
        //? if >=1.21.6 {
        g.method_51448().scale(scale, scale);
        //?} else {
        /*g.pose().scale(scale, scale, 1f);*/
        //?}
        g.method_27534(font, c, (int) (cx / scale), (int) (y / scale), color);
        g.method_51448().popMatrix();
    }

    // --- Misc ---

    public static void item(class_332 g, class_1799 stack, int x, int y) {
        g.method_51427(stack, x, y);
    }

    public static void outline(class_332 g, int x, int y, int w, int h, int color) {
        //? if >=1.21.11 {
        /*g.renderOutline(x, y, w, h, color);
        *///?} else {
        g.method_25294(x, y, x + w, y + 1, color);
        g.method_25294(x, y + h - 1, x + w, y + h, color);
        g.method_25294(x, y, x + 1, y + h, color);
        g.method_25294(x + w - 1, y, x + w, y + h, color);
        //?}
    }
}
