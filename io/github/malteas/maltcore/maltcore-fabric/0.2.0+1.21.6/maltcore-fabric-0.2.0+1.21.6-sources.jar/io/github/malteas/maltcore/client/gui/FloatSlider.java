package io.github.malteas.maltcore.client.gui;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_357;

/** Float-ranged slider with stepping; the label comes from a value-to-Component formatter. */
public class FloatSlider extends class_357 {
    private final float min;
    private final float max;
    private final float step;
    private final Function<Float, class_2561> message;
    private final Consumer<Float> onChange;

    public FloatSlider(int x, int y, int width, int height,
                       float min, float max, float step, float initial,
                       Function<Float, class_2561> message, Consumer<Float> onChange) {
        super(x, y, width, height, class_2561.method_43473(), (initial - min) / (max - min));
        this.min = min;
        this.max = max;
        this.step = step;
        this.message = message;
        this.onChange = onChange;
        method_25346();
    }

    private float fromSlider() {
        float raw = (float) (this.field_22753 * (max - min) + min);
        return Math.round(raw / step) * step;
    }

    @Override
    protected void method_25346() {
        method_25355(message.apply(fromSlider()));
    }

    @Override
    protected void method_25344() {
        onChange.accept(fromSlider());
    }
}
