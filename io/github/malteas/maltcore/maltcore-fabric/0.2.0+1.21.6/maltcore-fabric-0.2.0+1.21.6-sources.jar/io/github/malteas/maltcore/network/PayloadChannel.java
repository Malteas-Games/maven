package io.github.malteas.maltcore.network;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/*? if fabric {*/
import io.github.malteas.maltcore.platform.Platform;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
/*?}*/
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/*? if neoforge {*/
/*import net.neoforged.neoforge.network.registration.PayloadRegistrar;
*//*?}*/

/**
 * Fluent cross-loader payload registration; obtain via {@link MaltNetwork#channel}.
 *
 * <p>Handlers run on the receiving side's main thread. S2C handlers must not
 * reference client-only classes directly (route through a common-safe sink so a
 * dedicated server can classload the registration).
 *
 * <p>{@link #register()} must run during common init (Fabric {@code onInitialize})
 * / mod construction (NeoForge) — on NeoForge the channel is queued and drained
 * by malt-core when {@code RegisterPayloadHandlersEvent} fires.
 */
public final class PayloadChannel {

    @FunctionalInterface
    public interface ServerHandler<T extends class_8710> {
        void handle(T payload, class_3222 player);
    }

    private record Entry<T extends class_8710>(
            class_8710.class_9154<T> type,
            class_9139<? super class_9129, T> codec,
            ServerHandler<T> serverHandler,
            Consumer<T> clientHandler) {
    }

    private final String version;
    private final List<Entry<?>> entries = new ArrayList<>();
    private boolean registered;

    PayloadChannel(String version) {
        this.version = version;
    }

    String version() {
        return version;
    }

    /** Add a client-to-server payload; the handler runs on the server main thread. */
    public <T extends class_8710> PayloadChannel c2s(
            class_8710.class_9154<T> type,
            class_9139<? super class_9129, T> codec,
            ServerHandler<T> handler) {
        entries.add(new Entry<>(type, codec, handler, null));
        return this;
    }

    /** Add a server-to-client payload; the handler runs on the client main thread and must be common-safe. */
    public <T extends class_8710> PayloadChannel s2c(
            class_8710.class_9154<T> type,
            class_9139<? super class_9129, T> codec,
            Consumer<T> clientHandler) {
        entries.add(new Entry<>(type, codec, null, clientHandler));
        return this;
    }

    /** Apply (Fabric) or queue (NeoForge) every payload added so far. */
    public void register() {
        if (registered) {
            throw new IllegalStateException("PayloadChannel.register() called twice");
        }
        registered = true;
        /*? if fabric {*/
        for (Entry<?> entry : entries) {
            applyFabric(entry);
        }
        if (Platform.isClient()) {
            FabricClientReceivers.register(entries);
        }
        /*?}*/
        /*? if neoforge {*/
        /*MaltNetwork.enqueue(this);
        *//*?}*/
    }

    /*? if fabric {*/
    private static <T extends class_8710> void applyFabric(Entry<T> entry) {
        if (entry.serverHandler() != null) {
            PayloadTypeRegistry.playC2S().register(entry.type(), entry.codec());
            ServerPlayNetworking.registerGlobalReceiver(entry.type(),
                    (payload, context) -> entry.serverHandler().handle(payload, context.player()));
        } else {
            PayloadTypeRegistry.playS2C().register(entry.type(), entry.codec());
        }
    }

    // Client-only classes stay in this nested holder so register() from common
    // init doesn't classload them on a dedicated server.
    private static final class FabricClientReceivers {
        static void register(List<Entry<?>> entries) {
            for (Entry<?> entry : entries) {
                if (entry.clientHandler() != null) {
                    registerOne(entry);
                }
            }
        }

        private static <T extends class_8710> void registerOne(Entry<T> entry) {
            net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(
                    entry.type(), (payload, context) -> entry.clientHandler().accept(payload));
        }
    }
    /*?}*/

    /*? if neoforge {*/
    /*void apply(PayloadRegistrar registrar) {
        for (Entry<?> entry : entries) {
            applyNeoForge(registrar, entry);
        }
    }

    private static <T extends CustomPacketPayload> void applyNeoForge(PayloadRegistrar registrar, Entry<T> entry) {
        if (entry.serverHandler() != null) {
            registrar.playToServer(entry.type(), entry.codec(), (payload, context) ->
                    context.enqueueWork(() ->
                            entry.serverHandler().handle(payload, (ServerPlayer) context.player())));
        } else {
            registrar.playToClient(entry.type(), entry.codec(), (payload, context) ->
                    context.enqueueWork(() -> entry.clientHandler().accept(payload)));
        }
    }
    *//*?}*/
}
