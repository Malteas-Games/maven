package io.github.malteas.maltcore.client;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3965;

/**
 * Shared utilities for two-corner selection features (shapes, patterns, paint mode).
 */
public class SelectionUtils {

    /** Resolve the placement position (adjacent to the face hit). */
    public static class_2338 resolveTargetPos(class_310 mc) {
        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332) return null;
        class_3965 blockHit = (class_3965) mc.field_1765;
        return blockHit.method_17777().method_10093(blockHit.method_17780());
    }

    /**
     * Resolve the exact block being looked at, with no face offset — the block that would
     * be broken. Used by tools that operate on the targeted block itself (e.g. paint delete).
     */
    public static class_2338 resolveHitBlockPos(class_310 mc) {
        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332) return null;
        return ((class_3965) mc.field_1765).method_17777();
    }

    /**
     * Resolve the block being looked at, with UP/DOWN face offset.
     * When looking at a horizontal face (top/bottom), returns the adjacent position
     * so building on the ground or from a ceiling doesn't require nudging.
     */
    public static class_2338 resolveLookingAtPos(class_310 mc) {
        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332) return null;
        class_3965 blockHit = (class_3965) mc.field_1765;
        if (blockHit.method_17780() == class_2350.field_11036 || blockHit.method_17780() == class_2350.field_11033) {
            return blockHit.method_17777().method_10093(blockHit.method_17780());
        }
        return blockHit.method_17777();
    }

    /** Format a dimensions string like "8x4x3 = 96". */
    public static String getDimensionString(class_2338 c1, class_2338 c2) {
        int sizeX = Math.abs(c2.method_10263() - c1.method_10263()) + 1;
        int sizeY = Math.abs(c2.method_10264() - c1.method_10264()) + 1;
        int sizeZ = Math.abs(c2.method_10260() - c1.method_10260()) + 1;
        long volume = (long) sizeX * sizeY * sizeZ;
        return sizeX + "x" + sizeY + "x" + sizeZ + " = " + volume;
    }

    /** Check if a selection exceeds axis length or volume limits. */
    public static boolean isOversized(class_2338 c1, class_2338 c2, int maxAxisLength, long maxVolume) {
        int sizeX = Math.abs(c2.method_10263() - c1.method_10263()) + 1;
        int sizeY = Math.abs(c2.method_10264() - c1.method_10264()) + 1;
        int sizeZ = Math.abs(c2.method_10260() - c1.method_10260()) + 1;
        if (sizeX > maxAxisLength || sizeY > maxAxisLength || sizeZ > maxAxisLength) return true;
        return (long) sizeX * sizeY * sizeZ > maxVolume;
    }
}
