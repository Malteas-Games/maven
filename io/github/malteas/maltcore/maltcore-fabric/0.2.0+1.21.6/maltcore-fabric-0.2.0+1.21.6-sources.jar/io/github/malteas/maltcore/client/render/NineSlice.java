package io.github.malteas.maltcore.client.render;

import net.minecraft.class_2960;
import net.minecraft.class_332;

/** Nine-slice texture drawing: corners stay crisp, edges and center stretch. */
public final class NineSlice {
    private NineSlice() {}

    /**
     * Draw {@code tex} (natural size texW×texH) into the rectangle x,y,w,h,
     * keeping a {@code corner}-pixel border unscaled.
     */
    public static void draw(class_332 g, class_2960 tex, int x, int y, int w, int h,
                            int corner, int texW, int texH) {
        int midW = w - 2 * corner;
        int midH = h - 2 * corner;
        int texMidW = texW - 2 * corner;
        int texMidH = texH - 2 * corner;

        // Corners
        GuiDraw.region(g, tex, x, y, corner, corner, 0f, 0f, corner, corner, texW, texH);
        GuiDraw.region(g, tex, x + w - corner, y, corner, corner, texW - corner, 0f, corner, corner, texW, texH);
        GuiDraw.region(g, tex, x, y + h - corner, corner, corner, 0f, texH - corner, corner, corner, texW, texH);
        GuiDraw.region(g, tex, x + w - corner, y + h - corner, corner, corner, texW - corner, texH - corner, corner, corner, texW, texH);

        // Edges
        GuiDraw.region(g, tex, x + corner, y, midW, corner, corner, 0f, texMidW, corner, texW, texH);
        GuiDraw.region(g, tex, x + corner, y + h - corner, midW, corner, corner, texH - corner, texMidW, corner, texW, texH);
        GuiDraw.region(g, tex, x, y + corner, corner, midH, 0f, corner, corner, texMidH, texW, texH);
        GuiDraw.region(g, tex, x + w - corner, y + corner, corner, midH, texW - corner, corner, corner, texMidH, texW, texH);

        // Center
        GuiDraw.region(g, tex, x + corner, y + corner, midW, midH, corner, corner, texMidW, texMidH, texW, texH);
    }
}
