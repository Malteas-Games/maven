package io.github.malteas.maltcore.client;

import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * Version-safe client message helpers.
 * MC 26.1 split displayClientMessage into sendOverlayMessage / sendSystemMessage.
 */
public final class Chat {
    private Chat() {}

    /** Show a message in the action bar above the hotbar. */
    public static void actionBar(class_1657 player, class_2561 message) {
        //? if >=26.1 {
        /*player.sendOverlayMessage(message);
        *///?} else {
        player.method_7353(message, true);
        //?}
    }

    /** Show a message in the local player's action bar; no-op without a player. */
    public static void actionBar(class_2561 message) {
        class_1657 player = class_310.method_1551().field_1724;
        if (player != null) {
            actionBar(player, message);
        }
    }
}
