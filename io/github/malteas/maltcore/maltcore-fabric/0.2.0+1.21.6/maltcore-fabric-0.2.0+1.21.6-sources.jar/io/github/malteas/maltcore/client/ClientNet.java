package io.github.malteas.maltcore.client;

/*? if fabric {*/
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
/*?}*/
import net.minecraft.class_8710;

/*? if neoforge {*/
/*import net.minecraft.client.Minecraft;
//? if >=1.21.7 {
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
//?} else {
import net.neoforged.neoforge.network.PacketDistributor;
//?}
*//*?}*/

/** Client-to-server payload dispatch, abstracted over the loaders. */
public final class ClientNet {
    private ClientNet() {}

    public static void sendToServer(class_8710 payload) {
        /*? if fabric {*/
        ClientPlayNetworking.send(payload);
        /*?}*/
        /*? if neoforge {*/
        /*
        //? if >=1.21.7 {
        ClientPacketDistributor.sendToServer(payload);
        //?} else {
        PacketDistributor.sendToServer(payload);
        //?}
        *//*?}*/
    }

    /** True when connected and the server understands this payload type. */
    public static boolean canSend(class_8710.class_9154<?> type) {
        /*? if fabric {*/
        return ClientPlayNetworking.canSend(type);
        /*?}*/
        /*? if neoforge {*/
        /*var connection = Minecraft.getInstance().getConnection();
        return connection != null && connection.hasChannel(type);
        *//*?}*/
    }
}
