package io.github.malteas.maltcore.client.render;

import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

/**
 * Version-agnostic draw target for world rendering.
 *
 * <p>Through 26.1.x, world geometry is drawn immediately into a {@code MultiBufferSource}
 * (call {@code getBuffer(renderType)} and write vertices). In 26.2 that class was removed:
 * geometry is now <em>submitted</em> to a {@code SubmitNodeCollector} via
 * {@code submitCustomGeometry(...)}, which the engine renders later for batching.
 *
 * <p>{@code GeometrySink} hides that difference behind one method: callers hand over a render
 * type and a {@link Drawer} that writes into the supplied {@link class_4588}. The
 * {@code <26.2} implementation runs the drawer immediately; the {@code >=26.2} implementation
 * defers it to {@code submitCustomGeometry}. Renderers stay loader- and version-agnostic.
 */
@FunctionalInterface
public interface GeometrySink {

    /** Draw into {@code type}. The drawer receives the captured pose and a ready consumer. */
    void draw(class_4587 poseStack, class_1921 type, Drawer drawer);

    /** Writes geometry for a single render type. Signature matches 26.2's CustomGeometryRenderer. */
    @FunctionalInterface
    interface Drawer {
        void draw(class_4587.class_4665 pose, class_4588 vc);
    }

    //? if >=26.2 {
    /*static GeometrySink of(SubmitNodeCollector collector) {
        return (poseStack, type, drawer) -> collector.submitCustomGeometry(poseStack, type, drawer::draw);
    }*/
    //?} else {
    static GeometrySink of(class_4597 bufferSource) {
        return (poseStack, type, drawer) -> drawer.draw(poseStack.method_23760(), bufferSource.getBuffer(type));
    }
    //?}
}
