package io.github.malteas.maltcore.client.gui;

import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import net.minecraft.class_2561;
import net.minecraft.class_357;

/** Int-ranged slider with stepping; the label comes from a value-to-Component formatter. */
public class IntSlider extends class_357 {
    private final int min;
    private final int max;
    private final int step;
    private final IntFunction<class_2561> message;
    private final IntConsumer onChange;

    public IntSlider(int x, int y, int width, int height,
                     int min, int max, int step, int initial,
                     IntFunction<class_2561> message, IntConsumer onChange) {
        super(x, y, width, height, class_2561.method_43473(), (double) (initial - min) / (max - min));
        this.min = min;
        this.max = max;
        this.step = step;
        this.message = message;
        this.onChange = onChange;
        method_25346();
    }

    private int fromSlider() {
        int raw = (int) Math.round(this.field_22753 * (max - min) + min);
        return Math.round((float) raw / step) * step;
    }

    @Override
    protected void method_25346() {
        method_25355(message.apply(fromSlider()));
    }

    @Override
    protected void method_25344() {
        onChange.accept(fromSlider());
    }
}
