package io.github.malteas.maltcore.client;

import io.github.malteas.maltcore.client.command.ClientCommandFactory;
import io.github.malteas.maltcore.client.command.FeedbackSink;
/*? if fabric {*/
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
//? if >=1.21.11 {
/*import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
*///?} else {
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
//?}
/*?}*/
import net.minecraft.class_2960;
import net.minecraft.class_332;

/*? if neoforge {*/
/*import net.minecraft.commands.CommandSourceStack;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.common.NeoForge;
*//*?}*/

/**
 * Loader-neutral client event wiring. Every method applies immediately on both
 * loaders and can be called from client init (Fabric) or mod construction /
 * client setup (NeoForge).
 */
public final class ClientHooks {
    private ClientHooks() {}

    public static void onEndClientTick(Runnable tick) {
        /*? if fabric {*/
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick.run());
        /*?}*/
        /*? if neoforge {*/
        /*NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post event) -> tick.run());
        *//*?}*/
    }

    /** Runs after the client player disconnects from a world/server. */
    public static void onDisconnect(Runnable action) {
        /*? if fabric {*/
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> action.run());
        /*?}*/
        /*? if neoforge {*/
        /*NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut event) -> action.run());
        *//*?}*/
    }

    /** Runs after the client player joins a world/server. */
    public static void onJoin(Runnable action) {
        /*? if fabric {*/
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> action.run());
        /*?}*/
        /*? if neoforge {*/
        /*NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingIn event) -> action.run());
        *//*?}*/
    }

    @FunctionalInterface
    public interface HudLayer {
        void render(class_332 graphics, float partialTick);
    }

    /**
     * Add a HUD layer. Drawn before chat where the loader supports ordering
     * (Fabric 1.21.11+); elsewhere it draws after the vanilla HUD. partialTick
     * is best-effort and may be 0.
     */
    public static void addHudLayer(class_2960 id, HudLayer layer) {
        /*? if fabric {*/
        //? if >=1.21.11 {
        /*HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, id,
                (graphics, tickCounter) -> layer.render(graphics, 0f));
        *///?} else {
        HudRenderCallback.EVENT.register((graphics, tickCounter) -> layer.render(graphics, 0f));
        //?}
        /*?}*/
        /*? if neoforge {*/
        /*NeoForge.EVENT_BUS.addListener((RenderGuiEvent.Post event) ->
                layer.render(event.getGuiGraphics(), 0f));
        *//*?}*/
    }

    /** Register a client command tree; see {@link ClientCommandFactory} for the pattern. */
    public static void registerClientCommand(ClientCommandFactory factory) {
        /*? if fabric {*/
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(factory.build(new FeedbackSink<FabricClientCommandSource>() {
                    @Override
                    public void success(FabricClientCommandSource source, net.minecraft.class_2561 message) {
                        source.sendFeedback(message);
                    }

                    @Override
                    public void error(FabricClientCommandSource source, net.minecraft.class_2561 message) {
                        source.sendError(message);
                    }
                })));
        /*?}*/
        /*? if neoforge {*/
        /*NeoForge.EVENT_BUS.addListener((RegisterClientCommandsEvent event) ->
                event.getDispatcher().register(factory.build(new FeedbackSink<CommandSourceStack>() {
                    @Override
                    public void success(CommandSourceStack source, net.minecraft.network.chat.Component message) {
                        source.sendSuccess(() -> message, false);
                    }

                    @Override
                    public void error(CommandSourceStack source, net.minecraft.network.chat.Component message) {
                        source.sendFailure(message);
                    }
                })));
        *//*?}*/
    }
}
