//? if >=1.21.4 && <1.21.5 {
package io.github.malteas.maltcore.client.render;

import net.minecraft.class_10439;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4722;
import net.minecraft.class_638;
import net.minecraft.class_811;

// 1.21.4 only: renders an old-era BakedModel through the (then-new)
// client-items layer. Loader-neutral — used by the Fabric ClientItem injection
// and the NeoForge ModifyBakingResult injection alike.
public record LegacyItemModelWrapper(class_1087 baked) implements class_10439 {
    @Override
    public void method_65584(class_10444 renderState, class_1799 stack, class_10442 resolver,
                       class_811 displayContext, class_638 level, class_1309 owner, int seed) {
        renderState.method_65601().method_65618(this.baked, class_4722.method_24074());
    }
}
//?}
