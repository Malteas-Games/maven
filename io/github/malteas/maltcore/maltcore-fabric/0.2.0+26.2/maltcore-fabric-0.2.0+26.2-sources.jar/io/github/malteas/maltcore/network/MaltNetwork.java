package io.github.malteas.maltcore.network;

import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;

/*? if fabric {*/
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
/*?}*/

/*? if neoforge {*/
/*import java.util.ArrayList;
import java.util.List;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.slf4j.LoggerFactory;
*//*?}*/

/** Loader-neutral networking entry points; see {@link PayloadChannel} for registration. */
public final class MaltNetwork {
    private MaltNetwork() {}

    /** Create a payload channel; {@code version} is the NeoForge registrar version (e.g. "1"). */
    public static PayloadChannel channel(String version) {
        return new PayloadChannel(version);
    }

    /** Send a payload from the server to one player. */
    public static void sendToPlayer(ServerPlayer player, CustomPacketPayload payload) {
        /*? if fabric {*/
        ServerPlayNetworking.send(player, payload);
        /*?}*/
        /*? if neoforge {*/
        /*PacketDistributor.sendToPlayer(player, payload);
        *//*?}*/
    }

    /*? if neoforge {*/
    /*private static final List<PayloadChannel> PENDING = new ArrayList<>();
    private static boolean drained = false;

    static void enqueue(PayloadChannel channel) {
        synchronized (PENDING) {
            if (drained) {
                LoggerFactory.getLogger("maltcore").error(
                        "PayloadChannel.register() called after RegisterPayloadHandlersEvent already "
                        + "fired; these payloads will NOT work. Register during mod construction.");
                return;
            }
            PENDING.add(channel);
        }
    }

    // Internal: called by MaltCoreNeoForge.
    public static void drain(RegisterPayloadHandlersEvent event) {
        synchronized (PENDING) {
            for (PayloadChannel channel : PENDING) {
                channel.apply(event.registrar(channel.version()));
            }
            PENDING.clear();
            drained = true;
        }
    }
    *//*?}*/
}
