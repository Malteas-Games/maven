package io.github.malteas.maltcore.transfer;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/*? if fabric {*/
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
/*?}*/

/*? if neoforge && >1.21.8 {*/
/*import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.transaction.Transaction;
*//*?}*/

/**
 * Loader-neutral "push one item into the block at pos through side". Both item
 * APIs wrap vanilla containers automatically, so chests, hoppers, furnaces, etc.
 * work without a separate vanilla path.
 *
 * <p>NeoForge support requires the 1.21.9+ transfer API; on older NeoForge this
 * is a no-op returning false (add an IItemHandler path when a consumer needs it).
 */
public final class ItemSink {
    private ItemSink() {}

    /** @param side the face of the target block the item enters through */
    public static boolean insertOne(Level level, BlockPos pos, Direction side, ItemStack one) {
        /*? if fabric {*/
        Storage<ItemVariant> storage = ItemStorage.SIDED.find(level, pos, side);
        if (storage == null || !storage.supportsInsertion()) {
            return false;
        }
        try (Transaction tx = Transaction.openOuter()) {
            if (storage.insert(ItemVariant.of(one), 1, tx) == 1) {
                tx.commit();
                return true;
            }
        }
        return false;
        /*?} elif neoforge && >=1.21.10 {*/
        /*ResourceHandler<ItemResource> handler = level.getCapability(Capabilities.Item.BLOCK, pos, side);
        if (handler == null) {
            return false;
        }
        try (Transaction tx = Transaction.openRoot()) {
            if (handler.insert(ItemResource.of(one), 1, tx) == 1) {
                tx.commit();
                return true;
            }
        }
        return false;
        *//*?} elif neoforge && >1.21.8 {*/
        /*// NeoForge 21.9 has no openRoot(); open(null) starts a root transaction.
        ResourceHandler<ItemResource> handler = level.getCapability(Capabilities.Item.BLOCK, pos, side);
        if (handler == null) {
            return false;
        }
        try (Transaction tx = Transaction.open(null)) {
            if (handler.insert(ItemResource.of(one), 1, tx) == 1) {
                tx.commit();
                return true;
            }
        }
        return false;
        *//*?} else {*/
        /*// NeoForge <1.21.9 predates the transfer API this shim wraps.
        return false;
        *//*?}*/
    }
}
