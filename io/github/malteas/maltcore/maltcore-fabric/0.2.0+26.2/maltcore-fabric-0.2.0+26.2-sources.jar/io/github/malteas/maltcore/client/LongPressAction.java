package io.github.malteas.maltcore.client;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/**
 * Detects tap (short press) vs hold (long press) on a KeyMapping.
 * Call {@link #tick()} every client tick. Ignores presses while a screen is open.
 */
public class LongPressAction {
    private final KeyMapping key;
    private final int holdThreshold;
    private final Runnable onShortPress;
    private final Runnable onLongPress;

    private boolean wasDown = false;
    private int holdTicks = 0;

    public LongPressAction(KeyMapping key, int holdThreshold, Runnable onShortPress, Runnable onLongPress) {
        this.key = key;
        this.holdThreshold = holdThreshold;
        this.onShortPress = onShortPress;
        this.onLongPress = onLongPress;
    }

    public void tick() {
        Minecraft mc = Minecraft.getInstance();

        while (key.consumeClick()) {}

        boolean down = mc.gui.screen() == null && key.isDown();

        if (down) {
            holdTicks++;
            if (holdTicks == holdThreshold) {
                onLongPress.run();
            }
        } else {
            if (wasDown && holdTicks > 0 && holdTicks < holdThreshold && mc.gui.screen() == null) {
                onShortPress.run();
            }
            holdTicks = 0;
        }

        wasDown = down;
    }
}
