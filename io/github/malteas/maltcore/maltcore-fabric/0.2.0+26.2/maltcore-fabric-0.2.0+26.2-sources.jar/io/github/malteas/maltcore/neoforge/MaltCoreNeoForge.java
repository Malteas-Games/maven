//? if neoforge {
/*package io.github.malteas.maltcore.neoforge;

import io.github.malteas.maltcore.MaltCore;
import io.github.malteas.maltcore.client.MaltKeys;
import io.github.malteas.maltcore.network.MaltNetwork;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;

// malt-core's entire NeoForge runtime footprint: drain the registration queues
// consumers fill during mod construction (mod-bus registration events broadcast
// to every mod's bus, so malt-core can apply them from its own).
@Mod(MaltCore.MOD_ID)
public class MaltCoreNeoForge {
    public MaltCoreNeoForge(IEventBus modEventBus) {
        modEventBus.addListener(MaltNetwork::drain);
        if (FMLEnvironment.getDist() == Dist.CLIENT) {
            Client.init(modEventBus);
        }
    }

    // Client-only classes stay here so a dedicated server never loads them.
    private static final class Client {
        static void init(IEventBus modEventBus) {
            modEventBus.addListener(MaltKeys::drain);
        }
    }
}
*///?}
