package io.github.malteas.maltcore.client.render;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

/**
 * Draws vanilla-style container window chrome and slot cells by nine-slicing
 * the stock chest texture at runtime — pixel-identical to vanilla UIs (and
 * resource-pack aware) without shipping copied textures.
 */
public final class ContainerWindow {
    private ContainerWindow() {}

    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath("minecraft", "textures/gui/container/generic_54.png");

    // generic_54.png: window art is 176x222 in a 256x256 texture.
    private static final int TEX_WINDOW_WIDTH = 176;
    private static final int TEX_WINDOW_HEIGHT = 222;
    private static final int BORDER = 4;
    // An 18x18 slot cell (with its bevel) from the chest grid.
    private static final int SLOT_U = 7;
    private static final int SLOT_V = 17;

    /** Draw window chrome filling the given rectangle. */
    public static void draw(GuiGraphics graphics, int x, int y, int width, int height) {
        int b = BORDER;
        int innerW = width - 2 * b;
        int innerH = height - 2 * b;
        int rightU = TEX_WINDOW_WIDTH - b;
        int bottomV = TEX_WINDOW_HEIGHT - b;

        // Interior (a flat panel-colored patch from the texture's title band)
        slice(graphics, x + b, y + b, innerW, innerH, 100, 8, 4, 4);
        // Edges (stretched from 1-slice strips)
        slice(graphics, x + b, y, innerW, b, b, 0, TEX_WINDOW_WIDTH - 2 * b, b);
        slice(graphics, x + b, y + height - b, innerW, b, b, bottomV, TEX_WINDOW_WIDTH - 2 * b, b);
        slice(graphics, x, y + b, b, innerH, 0, b, b, TEX_WINDOW_HEIGHT - 2 * b);
        slice(graphics, x + width - b, y + b, b, innerH, rightU, b, b, TEX_WINDOW_HEIGHT - 2 * b);
        // Corners
        slice(graphics, x, y, b, b, 0, 0, b, b);
        slice(graphics, x + width - b, y, b, b, rightU, 0, b, b);
        slice(graphics, x, y + height - b, b, b, 0, bottomV, b, b);
        slice(graphics, x + width - b, y + height - b, b, b, rightU, bottomV, b, b);
    }

    /** Draw an 18x18 slot cell whose item position is (x, y). */
    public static void drawSlot(GuiGraphics graphics, int x, int y) {
        slice(graphics, x - 1, y - 1, 18, 18, SLOT_U, SLOT_V, 18, 18);
    }

    /** Draws a standalone 16x16 icon texture. */
    public static void icon(GuiGraphics graphics, Identifier texture, int x, int y) {
        icon(graphics, texture, x, y, 16);
    }

    /** Draws a standalone square icon texture of the given pixel size. */
    public static void icon(GuiGraphics graphics, Identifier texture, int x, int y, int size) {
        GuiDraw.region(graphics, texture, x, y, size, size, 0, 0, size, size, size, size);
    }

    private static void slice(GuiGraphics graphics, int dx, int dy, int dw, int dh,
                              int u, int v, int uw, int vh) {
        GuiDraw.region(graphics, TEXTURE, dx, dy, dw, dh, u, v, uw, vh, 256, 256);
    }
}
