//? if >=1.21.4 && <1.21.5 {
package io.github.malteas.maltcore.client.render;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.item.ItemModel;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

// 1.21.4 only: renders an old-era BakedModel through the (then-new)
// client-items layer. Loader-neutral — used by the Fabric ClientItem injection
// and the NeoForge ModifyBakingResult injection alike.
public record LegacyItemModelWrapper(BakedModel baked) implements ItemModel {
    @Override
    public void update(ItemStackRenderState renderState, ItemStack stack, ItemModelResolver resolver,
                       ItemDisplayContext displayContext, ClientLevel level, LivingEntity owner, int seed) {
        renderState.newLayer().setupBlockModel(this.baked, Sheets.cutoutBlockSheet());
    }
}
//?}
