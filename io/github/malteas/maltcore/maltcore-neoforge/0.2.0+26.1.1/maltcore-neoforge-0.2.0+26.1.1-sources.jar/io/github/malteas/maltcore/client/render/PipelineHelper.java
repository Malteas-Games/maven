//? if >=1.21.11 {
package io.github.malteas.maltcore.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;

/**
 * Centralizes version-specific RenderPipeline state configuration.
 * MC 26.1 replaced DepthTestFunction with DepthStencilState + CompareOp;
 * 26.3 moved the pipeline state classes into the renderpearl library.
 * (RenderPipeline itself only exists on 1.21.11+.)
 */
public class PipelineHelper {
    /** Apply "no depth test" to a pipeline builder. */
    public static RenderPipeline.Builder noDepthTest(RenderPipeline.Builder builder) {
        //? if >26.2 {
        /*return builder.withDepthStencilState(
                new com.mojang.renderpearl.api.pipeline.DepthStencilState(
                        com.mojang.renderpearl.api.pipeline.CompareOp.ALWAYS_PASS, false));
        *///?} elif >=26.1 {
        return builder.withDepthStencilState(
                new com.mojang.blaze3d.pipeline.DepthStencilState(
                        com.mojang.blaze3d.platform.CompareOp.ALWAYS_PASS, false, 0, 0));
        //?} else {
        /*return builder.withDepthTestFunction(
                com.mojang.blaze3d.platform.DepthTestFunction.NO_DEPTH_TEST)
                .withDepthWrite(false);
        *///?}
    }

    /** Apply translucent blend to a pipeline builder. */
    public static RenderPipeline.Builder translucentBlend(RenderPipeline.Builder builder) {
        //? if >26.2 {
        /*return builder.withColorTargetState(
                new com.mojang.renderpearl.api.pipeline.ColorTargetState(
                        com.mojang.renderpearl.api.pipeline.BlendFunction.TRANSLUCENT));
        *///?} elif >=26.1 {
        return builder.withColorTargetState(
                new com.mojang.blaze3d.pipeline.ColorTargetState(
                        com.mojang.blaze3d.pipeline.BlendFunction.TRANSLUCENT));
        //?} else {
        /*return builder.withBlend(com.mojang.blaze3d.pipeline.BlendFunction.TRANSLUCENT);
        *///?}
    }

    /** Apply "lequal depth test, no write" to a pipeline builder. */
    public static RenderPipeline.Builder lequalNoWrite(RenderPipeline.Builder builder) {
        //? if >26.2 {
        /*return builder.withDepthStencilState(
                new com.mojang.renderpearl.api.pipeline.DepthStencilState(
                        com.mojang.renderpearl.api.pipeline.CompareOp.LESS_THAN_OR_EQUAL, false));
        *///?} elif >=26.1 {
        return builder.withDepthStencilState(
                new com.mojang.blaze3d.pipeline.DepthStencilState(
                        com.mojang.blaze3d.platform.CompareOp.LESS_THAN_OR_EQUAL, false, 0, 0));
        //?} else {
        /*return builder.withDepthTestFunction(
                com.mojang.blaze3d.platform.DepthTestFunction.LEQUAL_DEPTH_TEST)
                .withDepthWrite(false);
        *///?}
    }
}
//?}
