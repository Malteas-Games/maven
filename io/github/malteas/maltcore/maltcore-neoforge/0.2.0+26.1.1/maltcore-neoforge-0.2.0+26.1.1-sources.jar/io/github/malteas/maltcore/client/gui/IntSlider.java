package io.github.malteas.maltcore.client.gui;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;
import java.util.function.IntFunction;

/** Int-ranged slider with stepping; the label comes from a value-to-Component formatter. */
public class IntSlider extends AbstractSliderButton {
    private final int min;
    private final int max;
    private final int step;
    private final IntFunction<Component> message;
    private final IntConsumer onChange;

    public IntSlider(int x, int y, int width, int height,
                     int min, int max, int step, int initial,
                     IntFunction<Component> message, IntConsumer onChange) {
        super(x, y, width, height, Component.empty(), (double) (initial - min) / (max - min));
        this.min = min;
        this.max = max;
        this.step = step;
        this.message = message;
        this.onChange = onChange;
        updateMessage();
    }

    private int fromSlider() {
        int raw = (int) Math.round(this.value * (max - min) + min);
        return Math.round((float) raw / step) * step;
    }

    @Override
    protected void updateMessage() {
        setMessage(message.apply(fromSlider()));
    }

    @Override
    protected void applyValue() {
        onChange.accept(fromSlider());
    }
}
