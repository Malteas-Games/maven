package io.github.malteas.maltcore.client.command;

import net.minecraft.network.chat.Component;

/** Loader-neutral command feedback: success and error channels for any source type. */
public interface FeedbackSink<S> {
    void success(S source, Component message);

    void error(S source, Component message);
}
