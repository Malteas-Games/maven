package io.github.malteas.maltcore.client.gui;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;
import java.util.function.Function;

/** Float-ranged slider with stepping; the label comes from a value-to-Component formatter. */
public class FloatSlider extends AbstractSliderButton {
    private final float min;
    private final float max;
    private final float step;
    private final Function<Float, Component> message;
    private final Consumer<Float> onChange;

    public FloatSlider(int x, int y, int width, int height,
                       float min, float max, float step, float initial,
                       Function<Float, Component> message, Consumer<Float> onChange) {
        super(x, y, width, height, Component.empty(), (initial - min) / (max - min));
        this.min = min;
        this.max = max;
        this.step = step;
        this.message = message;
        this.onChange = onChange;
        updateMessage();
    }

    private float fromSlider() {
        float raw = (float) (this.value * (max - min) + min);
        return Math.round(raw / step) * step;
    }

    @Override
    protected void updateMessage() {
        setMessage(message.apply(fromSlider()));
    }

    @Override
    protected void applyValue() {
        onChange.accept(fromSlider());
    }
}
