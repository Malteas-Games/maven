package io.github.malteas.maltcore.client.render;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
//? if >=1.21.6 {
import net.minecraft.client.renderer.RenderPipelines;
//?}

/**
 * Version-safe {@link GuiGraphics} drawing helpers. GuiGraphicsExtractor changed shape
 * repeatedly across the supported range (1.21.1 plain blits, 1.21.2 RenderType
 * function, 1.21.6 RenderPipelines + 2D pose stack, 26.1 extractor rename);
 * every fork lives here so mods draw through one stable API.
 */
public final class GuiDraw {
    private GuiDraw() {}

    /**
     * Blit a texture region at its natural size.
     * Note: on <=1.21.4 the raw blit does not set up alpha blending — callers
     * drawing translucent textures there wrap the call in RenderSystem blend.
     */
    public static void blit(GuiGraphicsExtractor g, Identifier tex, int x, int y,
                            float u, float v, int w, int h, int texW, int texH) {
        //? if >=1.21.6 {
        g.blit(RenderPipelines.GUI_TEXTURED, tex, x, y, u, v, w, h, texW, texH);
        //?} elif >=1.21.2 {
        /*g.blit(net.minecraft.client.renderer.rendertype.RenderType::guiTextured, tex, x, y, u, v, w, h, texW, texH);*/
        //?} else {
        /*g.blit(tex, x, y, u, v, w, h, texW, texH);*/
        //?}
    }

    /** Blit a texture region stretched to an arbitrary destination size (blend note as on {@link #blit}). */
    public static void region(GuiGraphicsExtractor g, Identifier tex, int dx, int dy, int dw, int dh,
                              float u, float v, int uw, int vh, int texW, int texH) {
        if (dw <= 0 || dh <= 0) return;
        //? if >=1.21.6 {
        g.blit(RenderPipelines.GUI_TEXTURED, tex, dx, dy, u, v, dw, dh, uw, vh, texW, texH);
        //?} elif >=1.21.2 {
        /*g.blit(net.minecraft.client.renderer.rendertype.RenderType::guiTextured, tex, dx, dy, u, v, dw, dh, uw, vh, texW, texH);*/
        //?} else {
        /*g.blit(tex, dx, dy, dw, dh, u, v, uw, vh, texW, texH);*/
        //?}
    }

    /** Draw a whole texture scaled to w×h. */
    public static void texture(GuiGraphicsExtractor g, Identifier tex, int x, int y, int w, int h) {
        region(g, tex, x, y, w, h, 0f, 0f, w, h, w, h);
    }

    public static void blitSprite(GuiGraphicsExtractor g, Identifier sprite, int x, int y, int w, int h) {
        //? if >=1.21.6 {
        g.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, x, y, w, h);
        //?} elif >=1.21.2 {
        /*g.blitSprite(net.minecraft.client.renderer.rendertype.RenderType::guiTextured, sprite, x, y, w, h);*/
        //?} else {
        /*g.blitSprite(sprite, x, y, w, h);*/
        //?}
    }

    /**
     * Blit a square texture centered on (cx, cy), rotated and scaled.
     * angle is in radians; textures pointing "up" rotate clockwise.
     */
    public static void rotatedBlit(GuiGraphicsExtractor g, Identifier tex, float cx, float cy,
                                   int size, float angleRadians, float scale) {
        //? if >=1.21.6 {
        g.pose().pushMatrix();
        g.pose().translate(cx, cy);
        g.pose().scale(scale, scale);
        g.pose().rotate(angleRadians);
        g.pose().translate(-size / 2f, -size / 2f);
        //? if >=26.1 {
        g.blit(tex, 0, 0, size, size, 0f, 0f, 1f, 1f);
        //?} else {
        /*g.blit(RenderPipelines.GUI_TEXTURED, tex, 0, 0, 0f, 0f, size, size, size, size, -1);
        *///?}
        g.pose().popMatrix();
        //?} else {
        /*g.pose().pushMatrix();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(scale, scale, 1);
        g.pose().mulPose(com.mojang.math.Axis.ZP.rotation(angleRadians));
        g.pose().translate(-size / 2f, -size / 2f, 0);
        //? if <=1.21.4 {
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
        //?}
        //? if <=1.21.1 {
        g.blit(tex, 0, 0, 0, 0, size, size, size, size);
        //?} else {
        g.blit(net.minecraft.client.renderer.rendertype.RenderType::guiTextured, tex, 0, 0, 0, 0, size, size, size, size);
        //?}
        //? if <=1.21.4 {
        com.mojang.blaze3d.systems.RenderSystem.disableBlend();
        //?}
        g.pose().popMatrix();
        *///?}
    }

    // --- Text ---

    public static void text(GuiGraphicsExtractor g, Font font, String s, int x, int y, int color) {
        g.text(font, s, x, y, color);
    }

    public static void text(GuiGraphicsExtractor g, Font font, String s, int x, int y, int color, boolean shadow) {
        g.text(font, s, x, y, color, shadow);
    }

    public static void text(GuiGraphicsExtractor g, Font font, Component c, int x, int y, int color) {
        g.text(font, c, x, y, color);
    }

    public static void centeredText(GuiGraphicsExtractor g, Font font, String s, int x, int y, int color) {
        g.centeredText(font, s, x, y, color);
    }

    public static void centeredText(GuiGraphicsExtractor g, Font font, Component c, int x, int y, int color) {
        g.centeredText(font, c, x, y, color);
    }

    /** Right-align text against a screen edge with the given padding. */
    public static void rightAlignedText(GuiGraphicsExtractor g, Font font, String s,
                                        int rightEdge, int y, int padding, int color) {
        text(g, font, s, rightEdge - font.width(s) - padding, y, color);
    }

    /** Draw text scaled around its own anchor point. */
    public static void scaledText(GuiGraphicsExtractor g, Font font, Component c,
                                  int x, int y, float scale, int color) {
        g.pose().pushMatrix();
        //? if >=1.21.6 {
        g.pose().scale(scale, scale);
        //?} else {
        /*g.pose().scale(scale, scale, 1f);*/
        //?}
        g.text(font, c, (int) (x / scale), (int) (y / scale), color);
        g.pose().popMatrix();
    }

    /** Draw centered text scaled around its own anchor point. */
    public static void scaledCenteredText(GuiGraphicsExtractor g, Font font, Component c,
                                          int cx, int y, float scale, int color) {
        g.pose().pushMatrix();
        //? if >=1.21.6 {
        g.pose().scale(scale, scale);
        //?} else {
        /*g.pose().scale(scale, scale, 1f);*/
        //?}
        g.centeredText(font, c, (int) (cx / scale), (int) (y / scale), color);
        g.pose().popMatrix();
    }

    // --- Misc ---

    public static void item(GuiGraphicsExtractor g, ItemStack stack, int x, int y) {
        g.item(stack, x, y);
    }

    public static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        //? if >=1.21.11 {
        g.outline(x, y, w, h, color);
        //?} else {
        /*g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);*/
        //?}
    }
}
