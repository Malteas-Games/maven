package io.github.malteas.maltcore.util;

import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;

/**
 * Camera-relative direction math — converts (right, forward, up) inputs
 * into world-space (dx, dy, dz) offsets based on the player's yaw.
 */
public record CameraRelativeOffset(int dx, int dy, int dz) {
    public static CameraRelativeOffset resolve(Player player, int right, int forward, int up) {
        Direction forwardDir = Direction.fromYRot(player.getYRot());
        Direction rightDir = forwardDir.getClockWise();

        int dx = forwardDir.getStepX() * forward + rightDir.getStepX() * right;
        int dy = up;
        int dz = forwardDir.getStepZ() * forward + rightDir.getStepZ() * right;

        return new CameraRelativeOffset(dx, dy, dz);
    }
}
