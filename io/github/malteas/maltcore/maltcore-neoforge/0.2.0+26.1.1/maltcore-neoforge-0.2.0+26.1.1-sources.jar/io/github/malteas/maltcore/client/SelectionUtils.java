package io.github.malteas.maltcore.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Shared utilities for two-corner selection features (shapes, patterns, paint mode).
 */
public class SelectionUtils {

    /** Resolve the placement position (adjacent to the face hit). */
    public static BlockPos resolveTargetPos(Minecraft mc) {
        if (mc.hitResult == null || mc.hitResult.getType() != HitResult.Type.BLOCK) return null;
        BlockHitResult blockHit = (BlockHitResult) mc.hitResult;
        return blockHit.getBlockPos().relative(blockHit.getDirection());
    }

    /**
     * Resolve the exact block being looked at, with no face offset — the block that would
     * be broken. Used by tools that operate on the targeted block itself (e.g. paint delete).
     */
    public static BlockPos resolveHitBlockPos(Minecraft mc) {
        if (mc.hitResult == null || mc.hitResult.getType() != HitResult.Type.BLOCK) return null;
        return ((BlockHitResult) mc.hitResult).getBlockPos();
    }

    /**
     * Resolve the block being looked at, with UP/DOWN face offset.
     * When looking at a horizontal face (top/bottom), returns the adjacent position
     * so building on the ground or from a ceiling doesn't require nudging.
     */
    public static BlockPos resolveLookingAtPos(Minecraft mc) {
        if (mc.hitResult == null || mc.hitResult.getType() != HitResult.Type.BLOCK) return null;
        BlockHitResult blockHit = (BlockHitResult) mc.hitResult;
        if (blockHit.getDirection() == Direction.UP || blockHit.getDirection() == Direction.DOWN) {
            return blockHit.getBlockPos().relative(blockHit.getDirection());
        }
        return blockHit.getBlockPos();
    }

    /** Format a dimensions string like "8x4x3 = 96". */
    public static String getDimensionString(BlockPos c1, BlockPos c2) {
        int sizeX = Math.abs(c2.getX() - c1.getX()) + 1;
        int sizeY = Math.abs(c2.getY() - c1.getY()) + 1;
        int sizeZ = Math.abs(c2.getZ() - c1.getZ()) + 1;
        long volume = (long) sizeX * sizeY * sizeZ;
        return sizeX + "x" + sizeY + "x" + sizeZ + " = " + volume;
    }

    /** Check if a selection exceeds axis length or volume limits. */
    public static boolean isOversized(BlockPos c1, BlockPos c2, int maxAxisLength, long maxVolume) {
        int sizeX = Math.abs(c2.getX() - c1.getX()) + 1;
        int sizeY = Math.abs(c2.getY() - c1.getY()) + 1;
        int sizeZ = Math.abs(c2.getZ() - c1.getZ()) + 1;
        if (sizeX > maxAxisLength || sizeY > maxAxisLength || sizeZ > maxAxisLength) return true;
        return (long) sizeX * sizeY * sizeZ > maxVolume;
    }
}
