package io.github.malteas.maltcore.config;

import org.slf4j.Logger;

import java.nio.file.Path;
import java.util.function.Supplier;

/**
 * Ready-made mod config: a {@link ConfigPersistence} plus the wrapper conventions
 * every mod was hand-writing (reset-then-load on init, log-instead-of-throw saves).
 *
 * <pre>
 *     public static final ModConfig&lt;ConfigData&gt; CONFIG =
 *         ModConfig.of("mymod.json", ConfigData.class, ConfigData::new, LOGGER);
 *
 *     // mod init:            CONFIG.init(configDir);
 *     // read anywhere:       CONFIG.data().someField
 *     // after a mutation:    CONFIG.save();  or  CONFIG.markDirty(); + per-tick CONFIG.saveIfDirty();
 * </pre>
 */
public final class ModConfig<T> {
    private final ConfigPersistence<T> persistence;
    private final Logger logger;

    private ModConfig(ConfigPersistence<T> persistence, Logger logger) {
        this.persistence = persistence;
        this.logger = logger;
    }

    public static <T> ModConfig<T> of(String fileName, Class<T> dataType, Supplier<T> defaults, Logger logger) {
        return new ModConfig<>(new ConfigPersistence<>(fileName, dataType, defaults), logger);
    }

    /** Store under {@code configDir/subDir/fileName}. */
    public static <T> ModConfig<T> of(String subDir, String fileName, Class<T> dataType, Supplier<T> defaults, Logger logger) {
        return new ModConfig<>(new ConfigPersistence<>(subDir, fileName, dataType, defaults), logger);
    }

    /** Reset to defaults, then load whatever exists under {@code configDir}. */
    public void init(Path configDir) {
        persistence.reset();
        persistence.init(configDir);
    }

    public T data() {
        return persistence.get();
    }

    public void save() {
        persistence.saveQuietly(logger);
    }

    public void markDirty() {
        persistence.markDirty();
    }

    /** Persist only if dirty; safe to call every tick. */
    public void saveIfDirty() {
        persistence.saveIfDirty(logger);
    }

    /** Escape hatch for tests and advanced callers. */
    public ConfigPersistence<T> persistence() {
        return persistence;
    }
}
