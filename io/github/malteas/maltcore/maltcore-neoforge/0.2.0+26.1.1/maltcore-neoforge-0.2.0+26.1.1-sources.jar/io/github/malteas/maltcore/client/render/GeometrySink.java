package io.github.malteas.maltcore.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.rendertype.RenderType;
//? if >=26.2 {
/*import net.minecraft.client.renderer.SubmitNodeCollector;*/
//?} else {
import net.minecraft.client.renderer.MultiBufferSource;
//?}

/**
 * Version-agnostic draw target for world rendering.
 *
 * <p>Through 26.1.x, world geometry is drawn immediately into a {@code MultiBufferSource}
 * (call {@code getBuffer(renderType)} and write vertices). In 26.2 that class was removed:
 * geometry is now <em>submitted</em> to a {@code SubmitNodeCollector} via
 * {@code submitCustomGeometry(...)}, which the engine renders later for batching.
 *
 * <p>{@code GeometrySink} hides that difference behind one method: callers hand over a render
 * type and a {@link Drawer} that writes into the supplied {@link VertexConsumer}. The
 * {@code <26.2} implementation runs the drawer immediately; the {@code >=26.2} implementation
 * defers it to {@code submitCustomGeometry}. Renderers stay loader- and version-agnostic.
 */
@FunctionalInterface
public interface GeometrySink {

    /** Draw into {@code type}. The drawer receives the captured pose and a ready consumer. */
    void draw(PoseStack poseStack, RenderType type, Drawer drawer);

    /** Writes geometry for a single render type. Signature matches 26.2's CustomGeometryRenderer. */
    @FunctionalInterface
    interface Drawer {
        void draw(PoseStack.Pose pose, VertexConsumer vc);
    }

    //? if >=26.2 {
    /*static GeometrySink of(SubmitNodeCollector collector) {
        return (poseStack, type, drawer) -> collector.submitCustomGeometry(poseStack, type, drawer::draw);
    }*/
    //?} else {
    static GeometrySink of(MultiBufferSource bufferSource) {
        return (poseStack, type, drawer) -> drawer.draw(poseStack.last(), bufferSource.getBuffer(type));
    }
    //?}
}
