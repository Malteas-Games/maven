package io.github.malteas.maltcore.client.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;

/**
 * Builds a client command tree, generic in the command-source type so one
 * definition serves both loaders. A generic method can't be a lambda — pass a
 * method reference to a static generic build method:
 *
 * <pre>
 *     public final class MyCommands {
 *         public static &lt;S&gt; LiteralArgumentBuilder&lt;S&gt; build(FeedbackSink&lt;S&gt; feedback) { ... }
 *     }
 *     ClientHooks.registerClientCommand(MyCommands::build);
 * </pre>
 */
public interface ClientCommandFactory {
    <S> LiteralArgumentBuilder<S> build(FeedbackSink<S> feedback);
}
