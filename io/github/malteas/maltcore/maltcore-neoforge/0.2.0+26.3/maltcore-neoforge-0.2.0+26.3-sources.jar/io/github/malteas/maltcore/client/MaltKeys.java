package io.github.malteas.maltcore.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
//? if >1.21.8 {
import net.minecraft.resources.Identifier;
//?}
/*? if fabric {*/
/*//? if >1.21.11 {
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
//?} else {
/^import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
^///?}
*//*?}*/

/*? if neoforge {*/
import java.util.ArrayList;
import java.util.List;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.slf4j.LoggerFactory;
/*?}*/

/**
 * Loader- and version-neutral keybinding creation and registration.
 *
 * <p>Call {@link #register} during client init (Fabric) / mod construction
 * (NeoForge). On NeoForge the mappings are queued and drained by malt-core's
 * own mod class when {@code RegisterKeyMappingsEvent} fires — calling after
 * that event has run is a bug and is logged loudly.
 */
public final class MaltKeys {
    private MaltKeys() {}

    /** Opaque keybinding category: {@code KeyMapping.Category} on 1.21.9+, a translation key before. */
    public static final class KeyCategory {
        //? if >1.21.8 {
        final KeyMapping.Category value;
        KeyCategory(KeyMapping.Category value) { this.value = value; }
        //?} else {
        /*final String value;
        KeyCategory(String value) { this.value = value; }
        *///?}
    }

    /**
     * Create (1.21.9+: register) a keybinding category.
     *
     * @param legacyTranslationKey the category translation key used before 1.21.9
     *                             (e.g. {@code "key.categories.mymod"}) — pre-1.21.9
     *                             lang files must keep that entry.
     */
    public static KeyCategory category(String namespace, String path, String legacyTranslationKey) {
        //? if >1.21.8 {
        return new KeyCategory(KeyMapping.Category.register(Identifier.fromNamespaceAndPath(namespace, path)));
        //?} else {
        /*return new KeyCategory(legacyTranslationKey);
        *///?}
    }

    /** Create a keyboard KeyMapping (use {@code InputConstants.KEY_*} for the code). */
    public static KeyMapping create(String translationKey, int keyCode, KeyCategory category) {
        return new KeyMapping(translationKey, InputConstants.Type.KEYBOARD, keyCode, category.value);
    }

    /**
     * Register keybindings. Fabric: applies immediately. NeoForge: queued for
     * malt-core's {@code RegisterKeyMappingsEvent} drain — call from mod construction.
     */
    public static void register(KeyMapping... keys) {
        /*? if fabric {*/
        /*for (KeyMapping key : keys) {
            //? if >1.21.11 {
            KeyMappingHelper.registerKeyMapping(key);
            //?} else {
            /^KeyBindingHelper.registerKeyBinding(key);
            ^///?}
        }
        *//*?}*/
        /*? if neoforge {*/
        synchronized (PENDING) {
            if (drained) {
                LoggerFactory.getLogger("maltcore").error(
                        "MaltKeys.register called after RegisterKeyMappingsEvent already fired; "
                        + "these keybindings will NOT work: {}", (Object) keys);
                return;
            }
            for (KeyMapping key : keys) {
                PENDING.add(key);
            }
        }
        /*?}*/
    }

    /*? if neoforge {*/
    private static final List<KeyMapping> PENDING = new ArrayList<>();
    private static boolean drained = false;

    // Internal: called by MaltCoreNeoForge.
    public static void drain(RegisterKeyMappingsEvent event) {
        synchronized (PENDING) {
            for (KeyMapping key : PENDING) {
                event.register(key);
            }
            PENDING.clear();
            drained = true;
        }
    }
    /*?}*/
}
