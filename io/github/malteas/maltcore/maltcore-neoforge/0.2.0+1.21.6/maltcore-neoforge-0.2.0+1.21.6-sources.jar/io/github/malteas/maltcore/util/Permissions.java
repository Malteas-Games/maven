package io.github.malteas.maltcore.util;

import net.minecraft.world.entity.player.Player;

/** Version-safe permission checks (the permission API was reworked in 1.21.11). */
public final class Permissions {
    private Permissions() {}

    /** True when the player may edit the world beyond survival play: op (cheats) or creative mode. */
    public static boolean canEditWorld(Player player) {
        //? if >=1.21.11 {
        /*boolean op = player.permissions().hasPermission(
                net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER);
        *///?} else {
        boolean op = player.hasPermissions(2);
        //?}
        return op || player.getAbilities().instabuild;
    }
}
