package io.github.malteas.maltcore.client.render;

import net.minecraft.client.Camera;
//? if >=1.21.6
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/**
 * Computes where an item's radar indicator should appear on the HUD.
 *
 * <p>Three zones:
 * <ol>
 *   <li><b>In FOV:</b> item is within the real (pitch-aware) view frustum.
 *       Marker placed at the item's exact projected screen position.</li>
 *   <li><b>In front, out of FOV:</b> item is in the forward hemisphere
 *       (horizontal) but off the real screen. The pitch-aware projection is
 *       computed and clamped to the screen edge — the arrow points exactly
 *       where the item would appear if the screen extended.</li>
 *   <li><b>Behind:</b> item is behind the player. Edge indicator uses the
 *       pitch-free (level) frame so left/right reflects which way to turn
 *       and up/down reflects the item's real elevation.</li>
 * </ol>
 */
public class ScreenEdgeProjection {

    private static final int MARGIN  = 40;
    private static final int PADDING = 40;

    public record Indicator(
            int screenX, int screenY,
            float angle,
            float distance,
            float yOffset,
            boolean onScreen,
            boolean behind
    ) {}

    public static Indicator project(Vec3 worldPos, Camera camera, float vFovRadians,
                                    int screenWidth, int screenHeight) {
        //? if >1.21.10 {
        /*Vec3 cameraPos = camera.position();
        float yawRad   = (float) Math.toRadians(camera.yRot());
        float pitchRad = (float) Math.toRadians(camera.xRot());
        *///?} else {
        Vec3 cameraPos = camera.getPosition();
        float yawRad   = (float) Math.toRadians(camera.getYRot());
        float pitchRad = (float) Math.toRadians(camera.getXRot());
        //?}
        //? if >=1.21.6 {
        // Prefer the game's own projection (exact matrices, real FOV including
        // sprint/spyglass modifiers) so on-screen markers land exactly on items.
        Indicator exact = projectExact(worldPos, cameraPos, yawRad, pitchRad,
                screenWidth, screenHeight);
        if (exact != null) return exact;
        //?}
        return projectFromView(worldPos, cameraPos, yawRad, pitchRad,
                vFovRadians, screenWidth, screenHeight);
    }

    //? if >=1.21.6 {
    /**
     * Projects with the game's real view/projection matrices via
     * {@code GameRenderer.projectPointToScreen}. Returns an exact on-screen
     * indicator, or {@code null} when the point is behind the camera or off
     * screen — those cases fall back to the analytic edge-indicator math.
     */
    private static Indicator projectExact(Vec3 worldPos, Vec3 cameraPos,
                                          float yawRad, float pitchRad,
                                          int screenWidth, int screenHeight) {
        double dx = worldPos.x - cameraPos.x;
        double dy = worldPos.y - cameraPos.y;
        double dz = worldPos.z - cameraPos.z;

        // transformProject loses the sign of w, so points behind the camera come
        // back mirrored — only trust it when the point is in front in view space.
        float sinYaw   = (float) Math.sin(yawRad);
        float cosYaw   = (float) Math.cos(yawRad);
        double forwardLevel = dx * -sinYaw + dz * cosYaw;
        float sinPitch = (float) Math.sin(pitchRad);
        float cosPitch = (float) Math.cos(pitchRad);
        double forwardView = forwardLevel * cosPitch - dy * sinPitch;
        if (forwardLevel <= 0 || forwardView <= 0) return null;

        Vec3 ndc = Minecraft.getInstance().gameRenderer.projectPointToScreen(worldPos);
        float sx = (float) ((ndc.x * 0.5 + 0.5) * screenWidth);
        float sy = (float) ((0.5 - ndc.y * 0.5) * screenHeight);
        if (!onScreen(sx, sy, screenWidth, screenHeight)) return null;

        float distance = (float) worldPos.distanceTo(cameraPos);
        float yOffset  = (float) (cameraPos.y - worldPos.y);
        float angle = (float) Math.atan2(sy - screenHeight / 2f, sx - screenWidth / 2f);
        return new Indicator(Math.round(sx), Math.round(sy),
                angle, distance, yOffset, true, false);
    }
    //?}

    /**
     * Pure projection math, testable without a {@link Camera} instance.
     *
     * @param yawRad   camera yaw in radians (Minecraft: 0 faces +Z)
     * @param pitchRad camera pitch in radians (Minecraft: positive looks down)
     * @param vFovRad  vertical field of view in radians
     */
    public static Indicator projectFromView(Vec3 worldPos, Vec3 cameraPos,
                                            float yawRad, float pitchRad, float vFovRad,
                                            int screenWidth, int screenHeight) {
        double dx = worldPos.x - cameraPos.x;
        double dy = worldPos.y - cameraPos.y;
        double dz = worldPos.z - cameraPos.z;

        float distance = (float) worldPos.distanceTo(cameraPos);
        float yOffset  = (float) (cameraPos.y - worldPos.y); // positive = item below camera

        // Express the offset in both frames.
        float sinYaw   = (float) Math.sin(yawRad);
        float cosYaw   = (float) Math.cos(yawRad);
        double right        = dx * -cosYaw + dz * -sinYaw;  // screen-right (yaw only)
        double forwardLevel = dx * -sinYaw + dz *  cosYaw;  // ahead (yaw only)
        double upLevel      = dy;                           // world +Y

        float sinPitch = (float) Math.sin(pitchRad);
        float cosPitch = (float) Math.cos(pitchRad);
        double forwardView = forwardLevel * cosPitch - upLevel * sinPitch; // real forward
        double upView      = forwardLevel * sinPitch + upLevel * cosPitch; // real up

        float halfV = vFovRad / 2f;
        float aspect = (float) screenWidth / screenHeight;
        float halfH  = (float) Math.atan(Math.tan(halfV) * aspect);
        float tanH   = (float) Math.tan(halfH);
        float tanV   = (float) Math.tan(halfV);

        float centerX = screenWidth  / 2f;
        float centerY = screenHeight / 2f;

        // --- Zones 1 & 2: item is in the forward hemisphere (horizontal) ---
        if (forwardLevel > 0) {
            float projX, projY;
            if (forwardView > 0) {
                // Pitch-aware gnomonic projection (zones 1 and 2).
                projX = centerX + (float) (right    / forwardView) / tanH * (screenWidth  / 2f);
                projY = centerY - (float) (upView   / forwardView) / tanV * (screenHeight / 2f);
            } else {
                // Camera pitched so far that the item crosses to the back of the real
                // view (rare). Fall back to the level projection for direction.
                projX = centerX + (float) (right    / forwardLevel) / tanH * (screenWidth  / 2f);
                projY = centerY - (float) (upLevel  / forwardLevel) / tanV * (screenHeight / 2f);
            }

            if (onScreen(projX, projY, screenWidth, screenHeight)) {
                // Zone 1: on screen — exact position.
                float angle = (float) Math.atan2(projY - centerY, projX - centerX);
                return new Indicator(Math.round(projX), Math.round(projY),
                        angle, distance, yOffset, true, false);
            }

            // Zone 2: in front, off screen — clamp the projection to the edge.
            return edgeIndicator(projX, projY, centerX, centerY, screenWidth, screenHeight,
                    distance, yOffset, false);
        }

        // --- Zone 3: behind — pitch-free compass edge indicator ---
        // Horizontal = turn direction (yaw only), vertical = real elevation.
        float dirX = (float)  right;
        float dirY = (float) -upLevel;
        if (Math.abs(dirX) < 1e-4f && Math.abs(dirY) < 1e-4f) {
            dirX = 0f; dirY = 1f; // directly behind and level — point straight down
        }
        float behindProjX = centerX + dirX;
        float behindProjY = centerY + dirY;
        return edgeIndicator(behindProjX, behindProjY, centerX, centerY, screenWidth, screenHeight,
                distance, yOffset, true);
    }

    /** Clamps the direction from screen-centre toward (projX, projY) to the padded rectangle. */
    private static Indicator edgeIndicator(float projX, float projY,
                                           float centerX, float centerY,
                                           int screenWidth, int screenHeight,
                                           float distance, float yOffset, boolean behind) {
        float dirX = projX - centerX;
        float dirY = projY - centerY;
        float halfBoxW = screenWidth  / 2f - PADDING;
        float halfBoxH = screenHeight / 2f - PADDING;
        float tX = dirX != 0f ? halfBoxW / Math.abs(dirX) : Float.MAX_VALUE;
        float tY = dirY != 0f ? halfBoxH / Math.abs(dirY) : Float.MAX_VALUE;
        float t  = Math.min(tX, tY);
        float edgeX = centerX + dirX * t;
        float edgeY = centerY + dirY * t;
        float angle = (float) Math.atan2(dirY, dirX);
        return new Indicator(Math.round(edgeX), Math.round(edgeY),
                angle, distance, yOffset, false, behind);
    }

    private static boolean onScreen(float x, float y, int w, int h) {
        return x >= MARGIN && x <= w - MARGIN && y >= MARGIN && y <= h - MARGIN;
    }
}
