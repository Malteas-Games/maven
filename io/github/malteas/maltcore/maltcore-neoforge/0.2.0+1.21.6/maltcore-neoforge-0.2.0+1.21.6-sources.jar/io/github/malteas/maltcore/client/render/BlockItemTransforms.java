package io.github.malteas.maltcore.client.render;

import net.minecraft.client.renderer.block.model.ItemTransform;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import org.joml.Vector3f;

/**
 * The standard block display transforms from minecraft:block/block
 * (translations are stored normalized, i.e. divided by 16). Shared by the
 * modern item model and the old-era (&lt;1.21.5) baked model.
 */
public final class BlockItemTransforms {

    private BlockItemTransforms() {}

    public static ItemTransforms blockTransforms() {
        ItemTransform thirdPerson = new ItemTransform(
                new Vector3f(75f, 45f, 0f), new Vector3f(0f, 2.5f / 16f, 0f), new Vector3f(0.375f));
        ItemTransform firstPersonRight = new ItemTransform(
                new Vector3f(0f, 45f, 0f), new Vector3f(), new Vector3f(0.4f));
        ItemTransform firstPersonLeft = new ItemTransform(
                new Vector3f(0f, 225f, 0f), new Vector3f(), new Vector3f(0.4f));
        ItemTransform gui = new ItemTransform(
                new Vector3f(30f, 225f, 0f), new Vector3f(), new Vector3f(0.625f));
        ItemTransform ground = new ItemTransform(
                new Vector3f(), new Vector3f(0f, 3f / 16f, 0f), new Vector3f(0.25f));
        ItemTransform fixed = new ItemTransform(
                new Vector3f(), new Vector3f(), new Vector3f(0.5f));
        return new ItemTransforms(
                thirdPerson, thirdPerson,
                firstPersonLeft, firstPersonRight,
                ItemTransform.NO_TRANSFORM,
                gui, ground, fixed
                // fixedFromBottom was added in 1.21.9.
                //? if >=1.21.9
                //, fixed
        );
    }
}
