package io.github.malteas.maltcore.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

/**
 * Version-safe client message helpers.
 * MC 26.1 split displayClientMessage into sendOverlayMessage / sendSystemMessage.
 */
public final class Chat {
    private Chat() {}

    /** Show a message in the action bar above the hotbar. */
    public static void actionBar(Player player, Component message) {
        //? if >=26.1 {
        /*player.sendOverlayMessage(message);
        *///?} else {
        player.displayClientMessage(message, true);
        //?}
    }

    /** Show a message in the local player's action bar; no-op without a player. */
    public static void actionBar(Component message) {
        Player player = Minecraft.getInstance().player;
        if (player != null) {
            actionBar(player, message);
        }
    }
}
