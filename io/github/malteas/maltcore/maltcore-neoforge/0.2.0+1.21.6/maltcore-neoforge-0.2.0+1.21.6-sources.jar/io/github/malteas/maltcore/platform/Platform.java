package io.github.malteas.maltcore.platform;

/*? if fabric {*/
/*import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
*//*?}*/

/*? if neoforge {*/
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.fml.loading.FMLPaths;
/*?}*/

import java.nio.file.Path;

/** Loader-neutral answers to the questions every mod's entrypoint asks. */
public final class Platform {
    private Platform() {}

    /** The instance config directory ({@code .minecraft/config}). */
    public static Path configDir() {
        /*? if fabric {*/
        /*return FabricLoader.getInstance().getConfigDir();
        *//*?} else {*/
        return FMLPaths.CONFIGDIR.get();
        /*?}*/
    }

    /** True on the physical client, false on a dedicated server. */
    public static boolean isClient() {
        /*? if fabric {*/
        /*return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
        *//*?} elif neoforge && >1.21.8 {*/
        /*return FMLEnvironment.dist == Dist.CLIENT;
        *//*?} else {*/
        return FMLEnvironment.dist == Dist.CLIENT;
        /*?}*/
    }
}
