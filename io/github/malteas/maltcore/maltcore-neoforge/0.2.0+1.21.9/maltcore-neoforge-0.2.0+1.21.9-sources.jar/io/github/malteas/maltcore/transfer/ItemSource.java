package io.github.malteas.maltcore.transfer;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.function.Predicate;

/*? if fabric {*/
/*import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
*//*?}*/

/*? if neoforge && >1.21.8 {*/
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.transaction.Transaction;
/*?}*/

/**
 * Loader-neutral "pull one item out of the block at pos through side". Counterpart
 * of {@link ItemSink}; respects the target's sidedness (e.g. furnace output only).
 *
 * <p>NeoForge support requires the 1.21.9+ transfer API; on older NeoForge this
 * is a no-op returning EMPTY (add an IItemHandler path when a consumer needs it).
 */
public final class ItemSource {
    private ItemSource() {}

    /**
     * @param side   the face of the source block the item leaves through
     * @param filter only items matching this may be taken
     * @return the extracted single item, or {@link ItemStack#EMPTY}
     */
    public static ItemStack extractOne(Level level, BlockPos pos, Direction side, Predicate<ItemStack> filter) {
        /*? if fabric {*/
        /*Storage<ItemVariant> storage = ItemStorage.SIDED.find(level, pos, side);
        if (storage == null || !storage.supportsExtraction()) {
            return ItemStack.EMPTY;
        }
        try (Transaction tx = Transaction.openOuter()) {
            for (StorageView<ItemVariant> view : storage) {
                if (view.isResourceBlank() || view.getAmount() <= 0) continue;
                ItemVariant variant = view.getResource();
                ItemStack one = variant.toStack(1);
                if (!filter.test(one)) continue;
                if (storage.extract(variant, 1, tx) == 1) {
                    tx.commit();
                    return one;
                }
            }
        }
        return ItemStack.EMPTY;
        *//*?} elif neoforge && >=1.21.10 {*/
        /*ResourceHandler<ItemResource> handler = level.getCapability(Capabilities.Item.BLOCK, pos, side);
        if (handler == null) {
            return ItemStack.EMPTY;
        }
        try (Transaction tx = Transaction.openRoot()) {
            for (int i = 0; i < handler.size(); i++) {
                ItemResource resource = handler.getResource(i);
                if (resource.isEmpty() || handler.getAmountAsLong(i) <= 0) continue;
                ItemStack one = resource.toStack(1);
                if (!filter.test(one)) continue;
                if (handler.extract(i, resource, 1, tx) == 1) {
                    tx.commit();
                    return one;
                }
            }
        }
        return ItemStack.EMPTY;
        *//*?} elif neoforge && >1.21.8 {*/
        ResourceHandler<ItemResource> handler = level.getCapability(Capabilities.Item.BLOCK, pos, side);
        if (handler == null) {
            return ItemStack.EMPTY;
        }
        try (Transaction tx = Transaction.open(null)) {
            for (int i = 0; i < handler.size(); i++) {
                ItemResource resource = handler.getResource(i);
                if (resource.isEmpty() || handler.getAmountAsLong(i) <= 0) continue;
                ItemStack one = resource.toStack(1);
                if (!filter.test(one)) continue;
                if (handler.extract(i, resource, 1, tx) == 1) {
                    tx.commit();
                    return one;
                }
            }
        }
        return ItemStack.EMPTY;
        /*?} else {*/
        /*// NeoForge <1.21.9 predates the transfer API this shim wraps.
        return ItemStack.EMPTY;
        *//*?}*/
    }
}
