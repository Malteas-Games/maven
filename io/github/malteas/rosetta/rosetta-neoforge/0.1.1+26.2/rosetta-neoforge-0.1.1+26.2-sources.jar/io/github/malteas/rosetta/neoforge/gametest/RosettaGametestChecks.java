//? if neoforge && >=1.21.9 {

package io.github.malteas.rosetta.neoforge.gametest;

import io.github.malteas.rosetta.CardCategory;
import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaNotification;
import io.github.malteas.rosetta.SimpleCard;
import io.github.malteas.rosetta.trigger.BuiltinTriggers;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.concurrent.atomic.AtomicReference;

// Shared assertions for the NeoForge gametests (both the legacy @GameTest API and the
// 1.21.5+ TestInstance API delegate here). Failures throw AssertionError, which the
// gametest framework reports as a test failure.
//
// Rosetta is a client-side mod, so these checks only exercise the loader-agnostic core:
// card registry, seen-state persistence, trigger queueing and the notification inbox.
// Screen display paths (drainPending/show) need a running client and are covered by
// unit tests with a mocked Minecraft instance instead.
final class RosettaGametestChecks {

    private RosettaGametestChecks() {}

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    static void cardRegistryRoundTrip() {
        Identifier id = Identifier.fromNamespaceAndPath("rosetta", "gametest_registry_card");
        SimpleCard card = new SimpleCard(id, Component.literal("Registry"), CardCategory.TUTORIAL, null)
                .addText(Component.literal("body"))
                .version(3);
        Rosetta.register(card);
        check(Rosetta.get(id).orElse(null) == card, "Rosetta.get should return the registered card");
        check(Rosetta.registered().containsKey(id), "Rosetta.registered should contain the registered card id");
        check(card.version() == 3 && card.category() == CardCategory.TUTORIAL,
                "SimpleCard getters should reflect builder values");
    }

    static void seenStateLifecycle() {
        Identifier id = Identifier.fromNamespaceAndPath("rosetta", "gametest_seen_card");
        Rosetta.register(new SimpleCard(id, Component.literal("Seen"), CardCategory.TIP, null));
        Rosetta.forget(id);
        check(!Rosetta.isSeen(id), "Card should be unseen after forget");
        Rosetta.markSeen(id);
        check(Rosetta.isSeen(id), "Card should be seen after markSeen");
        // Bumping the card version invalidates the stored seen state.
        Rosetta.register(new SimpleCard(id, Component.literal("Seen v2"), CardCategory.TIP, null).version(2));
        check(!Rosetta.isSeen(id), "Card with bumped version should be unseen again");
        Rosetta.markSeen(id);
        check(Rosetta.isSeen(id), "Card v2 should be seen after markSeen");
        Rosetta.forget(id);
        check(!Rosetta.isSeen(id), "Card should be unseen after forget");
    }

    static void triggerEnqueuesUnseenCardOnce() {
        Identifier id = Identifier.fromNamespaceAndPath("rosetta", "gametest_trigger_card");
        AtomicReference<Runnable> fire = new AtomicReference<>();
        Rosetta.register(new SimpleCard(id, Component.literal("Trigger"), CardCategory.NEWS,
                BuiltinTriggers.onEvent(fire::set)));
        Rosetta.forget(id);
        check(fire.get() != null, "Registering a card should register its trigger");
        fire.get().run();
        check(Rosetta.pendingCardIds().contains(id), "Firing the trigger should enqueue the unseen card");
        int count = Rosetta.pendingCardIds().size();
        fire.get().run();
        check(Rosetta.pendingCardIds().size() == count, "Firing the trigger twice should not enqueue the card twice");
        // A seen card must not be enqueued.
        Identifier seenId = Identifier.fromNamespaceAndPath("rosetta", "gametest_trigger_seen_card");
        AtomicReference<Runnable> fireSeen = new AtomicReference<>();
        Rosetta.register(new SimpleCard(seenId, Component.literal("Trigger seen"), CardCategory.NEWS,
                BuiltinTriggers.onEvent(fireSeen::set)));
        Rosetta.markSeen(seenId);
        fireSeen.get().run();
        check(!Rosetta.pendingCardIds().contains(seenId), "Firing the trigger for a seen card should not enqueue it");
        Rosetta.forget(seenId);
    }

    static void notificationInboxLifecycle() {
        Identifier id = Identifier.fromNamespaceAndPath("rosetta", "gametest_notification");
        RosettaNotification notification = new RosettaNotification(id, Component.literal("Hello"))
                .noSound()
                .color(0xFF00FF00);
        Rosetta.notify(notification);
        check(Rosetta.pendingNotifications().stream().anyMatch(n -> n.id().equals(id)),
                "Notification should be pending after notify");
        Rosetta.dismissNotification(id);
        check(Rosetta.pendingNotifications().stream().noneMatch(n -> n.id().equals(id)),
                "Notification should be gone after dismiss");
    }
}
//?}
