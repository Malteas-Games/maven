package io.github.malteas.rosetta.ui;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaNotification;
import io.github.malteas.rosetta.RosettaRendering;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;

public class NotificationScreen extends Screen {

    private static final int ENTRY_WIDTH = 320;
    private static final int ENTRY_HEIGHT = 24;
    private static final int ENTRY_GAP = 2;
    private static final int ICON_SIZE = 16;
    private static final int ICON_GAP = 4;
    private static final int BUTTON_WIDTH = 80;
    private static final int TOP_MARGIN = 40;
    private static final int TITLE_COLOR = 0xFFFFFFFF;
    private static final int MESSAGE_COLOR = 0xFFFFFFFF;
    private static final int BG_COLOR = 0xCC000000;

    private final Screen parent;

    public NotificationScreen(Screen parent) {
        super(Component.translatable("rosetta.notifications.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        // Auto-dismiss simple notifications (no Show action) on screen open
        Rosetta.pendingNotifications().stream()
                .filter(n -> !n.hasShowAction())
                .map(RosettaNotification::id)
                .toList()
                .forEach(Rosetta::dismissNotification);

        List<RosettaNotification> notifications = new ArrayList<>(Rosetta.pendingNotifications());
        int x = (this.width - ENTRY_WIDTH) / 2;
        int y = TOP_MARGIN;

        for (RosettaNotification notif : notifications) {
            if (notif.hasShowAction()) {
                int buttonX = x + ENTRY_WIDTH - BUTTON_WIDTH;
                addRenderableWidget(Button.builder(notif.showLabel(), b -> {
                    Rosetta.dismissNotification(notif.id());
                    notif.onShow().run();
                }).pos(buttonX, y + 2).width(BUTTON_WIDTH).build());
            }

            y += ENTRY_HEIGHT + ENTRY_GAP;
        }

        y += 12;
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .pos((this.width - 100) / 2, y).width(100).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        graphics.centeredText(this.font, this.title, this.width / 2, 16, TITLE_COLOR);

        List<RosettaNotification> notifications = Rosetta.pendingNotifications();
        if (notifications.isEmpty()) {
            graphics.centeredText(this.font, Component.translatable("rosetta.notifications.empty"),
                    this.width / 2, TOP_MARGIN + 4, 0xFFAAAAAA);
            return;
        }

        int x = (this.width - ENTRY_WIDTH) / 2;
        int y = TOP_MARGIN;

        for (RosettaNotification notif : notifications) {
            graphics.fill(x, y, x + ENTRY_WIDTH, y + ENTRY_HEIGHT, BG_COLOR);

            int textX = x + 4;
            int textY = y + (ENTRY_HEIGHT - 9) / 2;

            Identifier icon = notif.icon();
            if (icon != null) {
                int iconY = y + (ENTRY_HEIGHT - ICON_SIZE) / 2;
                RosettaRendering.renderTexture(graphics, icon, textX, iconY, ICON_SIZE, ICON_SIZE);
                textX += ICON_SIZE + ICON_GAP;
            }

            graphics.text(this.font, notif.message(), textX, textY, notif.color());
            y += ENTRY_HEIGHT + ENTRY_GAP;
        }
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }
}
