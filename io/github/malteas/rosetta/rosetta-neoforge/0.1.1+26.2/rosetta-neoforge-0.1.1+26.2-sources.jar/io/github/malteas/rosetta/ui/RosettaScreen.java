package io.github.malteas.rosetta.ui;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaOnboardCard;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.List;

public class RosettaScreen extends Screen {

    private static final int CARD_PADDING = 16;
    private static final int BUTTON_HEIGHT = 20;
    private static final int NAV_BUTTON_WIDTH = 80;
    private static final int DONE_BUTTON_WIDTH = 100;
    private static final int COUNTER_COLOR = 0xFFAAAAAA;

    private final List<RosettaOnboardCard> cards;
    private final int currentIndex;
    private final Screen parent;
    private final boolean markSeenOnNav;
    private final Runnable closeCallback;

    private boolean playedOpenSound;
    private int cardWidth;
    private int cardLeft;
    private int cardTop;
    private int cardHeight;
    private int contentHeight;
    private int buttonY;

    public RosettaScreen(RosettaOnboardCard card, Screen parent, Runnable closeCallback) {
        super(card.title());
        this.cards = List.of(card);
        this.currentIndex = 0;
        this.parent = parent;
        this.markSeenOnNav = false;
        this.closeCallback = closeCallback;
    }

    public RosettaScreen(List<RosettaOnboardCard> cards, int index, Screen parent, boolean markSeenOnNav) {
        super(cards.get(index).title());
        this.cards = cards;
        this.currentIndex = index;
        this.parent = parent;
        this.markSeenOnNav = markSeenOnNav;
        this.closeCallback = null;
    }

    private RosettaOnboardCard card() {
        return cards.get(currentIndex);
    }

    @Override
    protected void init() {
        if (!playedOpenSound && card().playAudio() && this.minecraft.player != null) {
            playedOpenSound = true;
            this.minecraft.player.playSound(SoundEvents.UI_TOAST_IN, 1.0f, 1.0f);
        }

        RosettaOnboardCard card = card();
        this.cardWidth = card.measureWidth();
        int contentWidth = cardWidth - 2 * CARD_PADDING;
        this.contentHeight = card.measureHeight(this.font, contentWidth);
        this.cardHeight = 3 * CARD_PADDING + contentHeight + BUTTON_HEIGHT;
        this.cardLeft = (this.width - cardWidth) / 2;
        this.cardTop = (this.height - cardHeight) / 2;

        this.buttonY = cardTop + 2 * CARD_PADDING + contentHeight;

        card.addWidgets(this::addRenderableWidget, this.font,
                cardLeft + CARD_PADDING, cardTop + CARD_PADDING,
                contentWidth, contentHeight);

        if (cards.size() > 1) {
            int navLeft = cardLeft + CARD_PADDING;
            int navRight = cardLeft + cardWidth - CARD_PADDING;

            if (currentIndex > 0) {
                addRenderableWidget(Button.builder(
                                Component.translatable("rosetta.back"), b -> goBack())
                        .pos(navLeft, buttonY).width(NAV_BUTTON_WIDTH).build());
            }

            boolean isLast = currentIndex == cards.size() - 1;
            Component label = isLast
                    ? Component.translatable("rosetta.done")
                    : Component.translatable("rosetta.next");
            addRenderableWidget(Button.builder(label, b -> {
                        if (isLast) onClose(); else goNext();
                    })
                    .pos(navRight - NAV_BUTTON_WIDTH, buttonY).width(NAV_BUTTON_WIDTH).build());
        } else {
            addRenderableWidget(Button.builder(
                            Component.translatable("rosetta.done"), b -> onClose())
                    .pos((this.width - DONE_BUTTON_WIDTH) / 2, buttonY)
                    .width(DONE_BUTTON_WIDTH).build());
        }
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractBackground(graphics, mouseX, mouseY, partialTick);
        RosettaOnboardCard card = card();
        card.drawBackground(graphics, cardLeft, cardTop, cardWidth, cardHeight);
        card.drawContent(graphics, this.font,
                cardLeft + CARD_PADDING, cardTop + CARD_PADDING,
                cardWidth - 2 * CARD_PADDING, contentHeight);

        if (cards.size() > 1) {
            String counter = (currentIndex + 1) + " / " + cards.size();
            graphics.centeredText(this.font, counter, this.width / 2, buttonY + 6, COUNTER_COLOR);
        }
    }

    private void goNext() {
        if (markSeenOnNav) {
            Rosetta.markSeen(card().id());
        }
        this.minecraft.setScreenAndShow(new RosettaScreen(cards, currentIndex + 1, parent, markSeenOnNav));
    }

    private void goBack() {
        this.minecraft.setScreenAndShow(new RosettaScreen(cards, currentIndex - 1, parent, markSeenOnNav));
    }

    @Override
    public void onClose() {
        if (card().playAudio() && this.minecraft.player != null) {
            this.minecraft.player.playSound(SoundEvents.UI_TOAST_OUT, 1.0f, 1.0f);
        }
        if (markSeenOnNav) {
            Rosetta.markSeen(card().id());
        }
        if (closeCallback != null) {
            closeCallback.run();
        }
        this.minecraft.setScreenAndShow(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
