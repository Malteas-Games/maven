package io.github.malteas.rosetta;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
//? if >=1.21.9 {
import net.minecraft.resources.ResourceLocation;
//?}

public final class RosettaKeys {

    //? if >=1.21.9 {
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            ResourceLocation.fromNamespaceAndPath("rosetta", "keys")
    );

    public static final KeyMapping NOTIFICATIONS = new KeyMapping(
            "key.rosetta.notifications",
            InputConstants.KEY_N,
            CATEGORY
    );
    //?} else {
    /*public static final KeyMapping NOTIFICATIONS = new KeyMapping(
            "key.rosetta.notifications",
            InputConstants.KEY_N,
            "key.categories.rosetta"
    );*/
    //?}

    private RosettaKeys() {}
}
