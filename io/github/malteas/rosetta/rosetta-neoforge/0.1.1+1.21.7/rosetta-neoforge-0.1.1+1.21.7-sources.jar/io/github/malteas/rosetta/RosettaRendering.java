package io.github.malteas.rosetta;

import io.github.malteas.maltcore.client.render.GuiDraw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public final class RosettaRendering {

    private RosettaRendering() {}

    public static void renderTexture(GuiGraphics g, ResourceLocation tex, int x, int y, int w, int h) {
        GuiDraw.texture(g, tex, x, y, w, h);
    }
}
