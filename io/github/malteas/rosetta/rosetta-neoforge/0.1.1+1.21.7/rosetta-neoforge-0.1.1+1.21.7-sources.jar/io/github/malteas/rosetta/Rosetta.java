package io.github.malteas.rosetta;

import io.github.malteas.rosetta.trigger.RosettaTrigger;
import io.github.malteas.rosetta.trigger.TriggerContext;
import io.github.malteas.rosetta.ui.NotificationScreen;
import io.github.malteas.rosetta.ui.RosettaReplayScreen;
import io.github.malteas.rosetta.ui.RosettaScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Rosetta {

    private static final Map<ResourceLocation, RosettaOnboardCard> REGISTRY = new HashMap<>();
    private static final Deque<ResourceLocation> PENDING = new ArrayDeque<>();
    private static final Set<ResourceLocation> PENDING_SET = new LinkedHashSet<>();
    private static final List<RosettaNotification> NOTIFICATIONS = new ArrayList<>();
    private static Runnable deferredAction;

    private Rosetta() {}

    public static void register(RosettaOnboardCard card) {
        Objects.requireNonNull(card, "card must not be null");
        REGISTRY.put(card.id(), card);
        RosettaTrigger trigger = card.trigger();
        if (trigger != null) {
            trigger.register(new TriggerContext(card.id()));
        }
    }

    public static Optional<RosettaOnboardCard> get(ResourceLocation id) {
        return Optional.ofNullable(REGISTRY.get(id));
    }

    public static Map<ResourceLocation, RosettaOnboardCard> registered() {
        return Collections.unmodifiableMap(REGISTRY);
    }

    public static boolean isSeen(ResourceLocation id) {
        RosettaOnboardCard card = REGISTRY.get(id);
        if (card == null) return false;
        return RosettaPersistence.get().isSeen(id, card.version());
    }

    public static void markSeen(ResourceLocation id) {
        RosettaOnboardCard card = REGISTRY.get(id);
        if (card == null) return;
        RosettaPersistence.get().markSeen(id, card.version());
    }

    public static void forget(ResourceLocation id) {
        RosettaPersistence.get().forget(id);
    }

    public static void forgetAll() {
        RosettaPersistence.get().forgetAll();
    }

    public static void showIfUnseen(ResourceLocation id) {
        if (isSeen(id)) return;
        enqueue(id);
    }

    public static void show(ResourceLocation id) {
        showScreen(id, null);
    }

    private static void showScreen(ResourceLocation id, Runnable closeCallback) {
        RosettaOnboardCard card = REGISTRY.get(id);
        if (card == null) return;
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new RosettaScreen(card, mc.screen, closeCallback));
    }

    public static void notify(RosettaNotification notification) {
        Objects.requireNonNull(notification, "notification must not be null");
        NOTIFICATIONS.add(notification);
        if (notification.playSound()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                mc.player.playSound(net.minecraft.sounds.SoundEvents.UI_TOAST_IN, 1.0f, 1.0f);
            }
        }
    }

    public static List<RosettaNotification> pendingNotifications() {
        return Collections.unmodifiableList(NOTIFICATIONS);
    }

    public static void dismissNotification(ResourceLocation id) {
        NOTIFICATIONS.removeIf(n -> n.id().equals(id));
    }

    public static void openNotificationScreen() {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new NotificationScreen(mc.screen));
    }

    public static void openReplayScreen() {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new RosettaReplayScreen(mc.screen));
    }

    static void enqueue(ResourceLocation id) {
        if (!REGISTRY.containsKey(id)) return;
        if (!PENDING_SET.add(id)) return;
        PENDING.addLast(id);
    }

    /** Card ids currently queued for display, in display order. */
    public static List<ResourceLocation> pendingCardIds() {
        return List.copyOf(PENDING);
    }

    // Test seam: clears all static state so tests can run in isolation.
    static void resetForTesting() {
        REGISTRY.clear();
        PENDING.clear();
        PENDING_SET.clear();
        NOTIFICATIONS.clear();
        deferredAction = null;
    }

    public static void defer(Runnable action) {
        deferredAction = action;
    }

    public static boolean isSafeToShow() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return false;
        if (player.isDeadOrDying()) return false;
        if (player.isSleeping()) return false;
        if (player.isFallFlying()) return false;
        if (player.isSpectator()) return false;
        if (player.hurtTime > 0) return false;
        return true;
    }

    public static void drainPending() {
        Minecraft mc = Minecraft.getInstance();
        if (deferredAction != null && mc.screen == null) {
            Runnable action = deferredAction;
            deferredAction = null;
            action.run();
            return;
        }
        if (PENDING.isEmpty()) return;
        if (mc.screen != null) return;
        if (!isSafeToShow()) return;

        List<RosettaOnboardCard> cards = new ArrayList<>();
        while (!PENDING.isEmpty()) {
            ResourceLocation id = PENDING.pollFirst();
            PENDING_SET.remove(id);
            RosettaOnboardCard card = REGISTRY.get(id);
            if (card != null) {
                cards.add(card);
            }
        }
        if (cards.isEmpty()) return;

        mc.setScreen(new RosettaScreen(cards, 0, null, true));
    }
}
