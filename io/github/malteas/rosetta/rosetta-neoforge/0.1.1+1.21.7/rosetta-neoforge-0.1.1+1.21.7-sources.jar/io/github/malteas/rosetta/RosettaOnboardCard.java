package io.github.malteas.rosetta;

import io.github.malteas.rosetta.trigger.RosettaTrigger;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public interface RosettaOnboardCard {

    ResourceLocation id();

    Component title();

    CardCategory category();

    RosettaTrigger trigger();

    int version();

    default ResourceLocation icon() {
        return null;
    }

    default int measureWidth() {
        return 300;
    }

    int measureHeight(Font font, int contentWidth);

    void drawContent(GuiGraphics graphics, Font font, int left, int top, int width, int height);

    default boolean playAudio() {
        return true;
    }

    default void drawBackground(GuiGraphics graphics, int left, int top, int width, int height) {
        graphics.fill(left, top, left + width, top + height, 0xCC000000);
    }

    default void addWidgets(java.util.function.Consumer<net.minecraft.client.gui.components.AbstractWidget> adder,
                            Font font, int contentLeft, int contentTop, int contentWidth, int contentHeight) {}
}
