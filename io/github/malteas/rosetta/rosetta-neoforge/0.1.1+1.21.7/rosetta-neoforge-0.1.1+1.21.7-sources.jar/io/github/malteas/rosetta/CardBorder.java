package io.github.malteas.rosetta;

import io.github.malteas.maltcore.client.render.NineSlice;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public interface CardBorder {

    void draw(GuiGraphics graphics, int left, int top, int width, int height);

    int inset();

    static CardBorder solid(int color) {
        return solid(color, 1);
    }

    static CardBorder solid(int color, int thickness) {
        return new CardBorder() {
            @Override
            public void draw(GuiGraphics g, int left, int top, int width, int height) {
                int r = left + width;
                int b = top + height;
                int t = thickness;
                g.fill(left, top, r, top + t, color);
                g.fill(left, b - t, r, b, color);
                g.fill(left, top + t, left + t, b - t, color);
                g.fill(r - t, top + t, r, b - t, color);
            }

            @Override
            public int inset() {
                return thickness;
            }
        };
    }

    static CardBorder texture(ResourceLocation tex, int cornerSize) {
        return new CardBorder() {
            @Override
            public void draw(GuiGraphics g, int left, int top, int width, int height) {
                NineSlice.draw(g, tex, left, top, width, height, cornerSize, width, height);
            }

            @Override
            public int inset() {
                return cornerSize;
            }
        };
    }
}
