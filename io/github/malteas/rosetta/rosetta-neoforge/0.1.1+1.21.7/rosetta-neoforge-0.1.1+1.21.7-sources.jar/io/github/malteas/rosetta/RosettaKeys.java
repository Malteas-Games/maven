package io.github.malteas.rosetta;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.malteas.maltcore.client.MaltKeys;
import net.minecraft.client.KeyMapping;

public final class RosettaKeys {

    public static final KeyMapping NOTIFICATIONS = MaltKeys.create(
            "key.rosetta.notifications",
            InputConstants.KEY_N,
            MaltKeys.category("rosetta", "keys", "key.categories.rosetta"));

    private RosettaKeys() {}
}
