package io.github.malteas.rosetta.trigger;

import io.github.malteas.rosetta.Rosetta;
import net.minecraft.resources.ResourceLocation;

public final class TriggerContext {

    private final ResourceLocation cardId;

    public TriggerContext(ResourceLocation cardId) {
        this.cardId = cardId;
    }

    public ResourceLocation cardId() {
        return cardId;
    }

    public void fire() {
        Rosetta.showIfUnseen(cardId);
    }
}
