package io.github.malteas.rosetta.trigger;

public interface RosettaTrigger {
    void register(TriggerContext ctx);
}
