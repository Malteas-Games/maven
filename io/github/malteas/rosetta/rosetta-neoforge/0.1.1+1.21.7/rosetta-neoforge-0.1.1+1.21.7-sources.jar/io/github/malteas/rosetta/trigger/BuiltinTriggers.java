package io.github.malteas.rosetta.trigger;

//? if fabric {
/*import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
*///?} elif neoforge {
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
//?}

import java.util.function.Consumer;

public final class BuiltinTriggers {

    private BuiltinTriggers() {}

    public static RosettaTrigger firstLoad() {
        return ctx -> {
            //? if fabric {
            /*ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> ctx.fire());
            *///?} elif neoforge {
            NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingIn event) -> ctx.fire());
            //?}
        };
    }

    public static RosettaTrigger onEvent(Consumer<Runnable> registrar) {
        return ctx -> registrar.accept(ctx::fire);
    }
}
