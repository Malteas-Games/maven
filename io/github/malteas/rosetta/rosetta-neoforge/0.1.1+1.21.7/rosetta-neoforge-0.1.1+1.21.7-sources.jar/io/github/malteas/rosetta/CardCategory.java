package io.github.malteas.rosetta;

public enum CardCategory {
    TUTORIAL,
    TIP,
    WARNING,
    NEWS,
    CREDITS
}
