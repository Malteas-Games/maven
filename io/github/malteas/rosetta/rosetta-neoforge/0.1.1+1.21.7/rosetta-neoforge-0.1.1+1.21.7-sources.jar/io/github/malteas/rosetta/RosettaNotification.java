package io.github.malteas.rosetta;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.Objects;

public class RosettaNotification {

    private final ResourceLocation id;
    private final Component message;
    private ResourceLocation icon;
    private int color = 0xFFFFFFFF;
    private boolean playSound = true;
    private Runnable onShow;
    private Component showLabel;

    public RosettaNotification(ResourceLocation id, Component message) {
        this.id = Objects.requireNonNull(id);
        this.message = Objects.requireNonNull(message);
    }

    public RosettaNotification icon(ResourceLocation icon) {
        this.icon = icon;
        return this;
    }

    public RosettaNotification color(int argb) {
        this.color = argb;
        return this;
    }

    public RosettaNotification noSound() {
        this.playSound = false;
        return this;
    }

    public RosettaNotification onShow(Component label, Runnable action) {
        this.showLabel = Objects.requireNonNull(label);
        this.onShow = Objects.requireNonNull(action);
        return this;
    }

    public ResourceLocation id() { return id; }
    public Component message() { return message; }
    public ResourceLocation icon() { return icon; }
    public int color() { return color; }
    public boolean playSound() { return playSound; }
    public Runnable onShow() { return onShow; }
    public Component showLabel() { return showLabel; }
    public boolean hasShowAction() { return onShow != null; }
}
