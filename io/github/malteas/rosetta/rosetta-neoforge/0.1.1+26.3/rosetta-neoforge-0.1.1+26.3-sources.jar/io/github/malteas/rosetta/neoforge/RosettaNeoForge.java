//? if neoforge {

package io.github.malteas.rosetta.neoforge;

import io.github.malteas.rosetta.RosettaWiring;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;

@Mod("rosetta")
public class RosettaNeoForge {
    public RosettaNeoForge(IEventBus modEventBus, ModContainer modContainer) {
        if (FMLEnvironment.getDist() == Dist.CLIENT) {
            RosettaWiring.initClient();
        }
    }
}
//?}
