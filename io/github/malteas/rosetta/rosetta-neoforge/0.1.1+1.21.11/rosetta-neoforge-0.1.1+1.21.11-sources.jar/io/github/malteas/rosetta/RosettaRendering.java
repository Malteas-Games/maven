package io.github.malteas.rosetta;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
//? if >=1.21.2 && <1.21.6 {
/*import net.minecraft.client.renderer.RenderType;*/
//?}

public final class RosettaRendering {

    private RosettaRendering() {}

    public static void renderTexture(GuiGraphics g, Identifier tex, int x, int y, int w, int h) {
        //? if >=1.21.6 {
        g.blit(tex, x, y, x + w, y + h, 0f, 1f, 0f, 1f);
        //?} elif >=1.21.2 {
        /*g.blit(RenderType::guiTextured, tex, x, y, 0f, 0f, w, h, w, h);*/
        //?} else {
        /*g.blit(tex, x, y, 0f, 0f, w, h, w, h);*/
        //?}
    }
}
