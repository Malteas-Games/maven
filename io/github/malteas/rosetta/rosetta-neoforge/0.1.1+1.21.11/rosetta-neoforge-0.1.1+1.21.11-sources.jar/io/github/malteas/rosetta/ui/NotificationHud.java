package io.github.malteas.rosetta.ui;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaKeys;
import io.github.malteas.rosetta.RosettaNotification;
import io.github.malteas.rosetta.RosettaRendering;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.List;

public final class NotificationHud {

    private static final int BAR_HEIGHT = 20;
    private static final int BAR_PADDING = 4;
    private static final int ICON_SIZE = 12;
    private static final int BG_COLOR = 0xCC000000;
    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int HINT_COLOR = 0xFFAAAAAA;

    private NotificationHud() {}

    public static void draw(GuiGraphics graphics) {
        List<RosettaNotification> notifications = Rosetta.pendingNotifications();
        if (notifications.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null) return;

        Font font = mc.font;
        int screenWidth = mc.getWindow().getGuiScaledWidth();

        RosettaNotification latest = notifications.get(notifications.size() - 1);
        String keyName = RosettaKeys.NOTIFICATIONS.getTranslatedKeyMessage().getString();

        Component messageText;
        if (notifications.size() == 1) {
            messageText = latest.message();
        } else {
            messageText = Component.literal(notifications.size() + " notifications");
        }

        Component hint = Component.literal(" - Press [" + keyName + "]");
        int messageWidth = font.width(messageText);
        int hintWidth = font.width(hint);
        int iconSpace = latest.icon() != null ? ICON_SIZE + BAR_PADDING : 0;
        int totalWidth = BAR_PADDING + iconSpace + messageWidth + hintWidth + BAR_PADDING;

        int barLeft = (screenWidth - totalWidth) / 2;
        int barTop = 4;

        graphics.fill(barLeft, barTop, barLeft + totalWidth, barTop + BAR_HEIGHT, BG_COLOR);

        int x = barLeft + BAR_PADDING;
        int textY = barTop + (BAR_HEIGHT - 9) / 2;

        if (latest.icon() != null) {
            int iconY = barTop + (BAR_HEIGHT - ICON_SIZE) / 2;
            RosettaRendering.renderTexture(graphics, latest.icon(), x, iconY, ICON_SIZE, ICON_SIZE);
            x += ICON_SIZE + BAR_PADDING;
        }

        graphics.drawString(font, messageText, x, textY, latest.color());
        x += messageWidth;
        graphics.drawString(font, hint, x, textY, HINT_COLOR);
    }
}
