package io.github.malteas.rosetta.ui;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaOnboardCard;
import io.github.malteas.rosetta.RosettaRendering;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class RosettaReplayScreen extends Screen {

    private static final int BUTTON_WIDTH = 260;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 4;
    private static final int TOP_MARGIN = 40;
    private static final int ICON_SIZE = 16;
    private static final int ICON_GAP = 4;
    private static final int TITLE_COLOR = 0xFFFFFFFF;
    private static final int DIM_COLOR = 0xFFAAAAAA;

    private final Screen parent;
    private final List<IconEntry> iconEntries = new ArrayList<>();

    private record IconEntry(Identifier texture, int x, int y) {}

    public RosettaReplayScreen(Screen parent) {
        super(Component.translatable("rosetta.replay.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        iconEntries.clear();

        Map<Identifier, RosettaOnboardCard> registered = Rosetta.registered();
        List<Identifier> ids = new ArrayList<>(registered.keySet());
        ids.sort(Comparator.comparing(Identifier::toString));

        int x = (this.width - BUTTON_WIDTH) / 2;
        int y = TOP_MARGIN;

        for (Identifier id : ids) {
            RosettaOnboardCard card = registered.get(id);
            Identifier icon = card.icon();
            if (icon != null) {
                iconEntries.add(new IconEntry(icon, x - ICON_SIZE - ICON_GAP, y + (BUTTON_HEIGHT - ICON_SIZE) / 2));
            }
            addRenderableWidget(Button.builder(card.title(), button -> Rosetta.show(id))
                    .pos(x, y)
                    .width(BUTTON_WIDTH)
                    .build());
            y += BUTTON_HEIGHT + BUTTON_GAP;
        }

        y += BUTTON_GAP + 8;

        addRenderableWidget(Button.builder(Component.translatable("gui.done"), button -> onClose())
                .pos(x, y)
                .width(BUTTON_WIDTH)
                .build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 16, TITLE_COLOR);

        for (IconEntry entry : iconEntries) {
            RosettaRendering.renderTexture(graphics, entry.texture(), entry.x(), entry.y(), ICON_SIZE, ICON_SIZE);
        }

        if (Rosetta.registered().isEmpty()) {
            graphics.drawCenteredString(
                    this.font,
                    Component.translatable("rosetta.replay.empty"),
                    this.width / 2,
                    TOP_MARGIN + 4,
                    DIM_COLOR);
        }
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
