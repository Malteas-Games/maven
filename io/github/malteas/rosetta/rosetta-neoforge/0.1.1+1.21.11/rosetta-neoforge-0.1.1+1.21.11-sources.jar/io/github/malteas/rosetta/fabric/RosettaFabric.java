//? if fabric {
/*package io.github.malteas.rosetta.fabric;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaKeys;
import io.github.malteas.rosetta.ui.NotificationHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
//? if >=1.21.11 {
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.Identifier;
//?} else {
/^import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;^/
//?}
//? if >=26.1 {
/^import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;^/
//?} else {
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
//?}

public class RosettaFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Rosetta.drainPending();
            if (RosettaKeys.NOTIFICATIONS.consumeClick()) {
                Rosetta.openNotificationScreen();
            }
        });

        RosettaCommands.register();

        //? if >=26.1 {
        /^KeyMappingHelper.registerKeyMapping(RosettaKeys.NOTIFICATIONS);^/
        //?} else {
        KeyBindingHelper.registerKeyBinding(RosettaKeys.NOTIFICATIONS);
        //?}

        //? if >=1.21.11 {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("rosetta", "notifications"),
                (graphics, tickCounter) -> NotificationHud.draw(graphics)
        );
        //?} else {
        /^HudRenderCallback.EVENT.register((graphics, tickCounter) ->
                NotificationHud.draw(graphics));^/
        //?}
    }
}
*///?}
