//? if neoforge {
/*
package io.github.malteas.rosetta.neoforge;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.malteas.rosetta.Rosetta;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.concurrent.CompletableFuture;

public final class RosettaCommands {

    private RosettaCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext buildContext) {
        dispatcher.register(Commands.literal("rosetta")
            .then(Commands.literal("reset")
                .executes(RosettaCommands::resetAll)
                .then(Commands.argument("id", StringArgumentType.greedyString())
                    .suggests(RosettaCommands::suggestCards)
                    .executes(RosettaCommands::resetOne)))
            .then(Commands.literal("show")
                .then(Commands.argument("id", StringArgumentType.greedyString())
                    .suggests(RosettaCommands::suggestCards)
                    .executes(RosettaCommands::show)))
            .then(Commands.literal("list")
                .executes(RosettaCommands::list))
            .then(Commands.literal("replay")
                .executes(RosettaCommands::replay)));
    }

    private static int resetAll(CommandContext<CommandSourceStack> ctx) {
        Rosetta.forgetAll();
        ctx.getSource().sendSuccess(() -> Component.literal("[rosetta] Reset all card state."), false);
        return 1;
    }

    private static int resetOne(CommandContext<CommandSourceStack> ctx) {
        ResourceLocation id = parseId(ctx);
        if (id == null) return 0;
        Rosetta.forget(id);
        ctx.getSource().sendSuccess(() -> Component.literal("[rosetta] Reset " + id + "."), false);
        return 1;
    }

    private static int show(CommandContext<CommandSourceStack> ctx) {
        ResourceLocation id = parseId(ctx);
        if (id == null) return 0;
        if (Rosetta.get(id).isEmpty()) {
            ctx.getSource().sendFailure(Component.literal("[rosetta] No card registered with id " + id));
            return 0;
        }
        Rosetta.defer(() -> Rosetta.show(id));
        return 1;
    }

    private static int replay(CommandContext<CommandSourceStack> ctx) {
        Rosetta.defer(Rosetta::openReplayScreen);
        return 1;
    }

    private static int list(CommandContext<CommandSourceStack> ctx) {
        var registered = Rosetta.registered();
        if (registered.isEmpty()) {
            ctx.getSource().sendSuccess(() -> Component.literal("[rosetta] No cards registered."), false);
            return 1;
        }
        ctx.getSource().sendSuccess(() -> Component.literal("[rosetta] Registered cards (" + registered.size() + "):"), false);
        for (ResourceLocation id : registered.keySet()) {
            String marker = Rosetta.isSeen(id) ? " [seen]" : "";
            ctx.getSource().sendSuccess(() -> Component.literal("  - " + id + marker), false);
        }
        return 1;
    }

    private static CompletableFuture<Suggestions> suggestCards(CommandContext<CommandSourceStack> ctx, SuggestionsBuilder builder) {
        for (ResourceLocation id : Rosetta.registered().keySet()) {
            String s = id.toString();
            if (s.startsWith(builder.getRemaining()) || s.contains(builder.getRemaining())) {
                builder.suggest(s);
            }
        }
        return builder.buildFuture();
    }

    private static ResourceLocation parseId(CommandContext<CommandSourceStack> ctx) {
        String raw = StringArgumentType.getString(ctx, "id");
        ResourceLocation id = ResourceLocation.tryParse(raw);
        if (id == null) {
            ctx.getSource().sendFailure(Component.literal("[rosetta] Invalid identifier: " + raw));
        }
        return id;
    }
}
*///?}
