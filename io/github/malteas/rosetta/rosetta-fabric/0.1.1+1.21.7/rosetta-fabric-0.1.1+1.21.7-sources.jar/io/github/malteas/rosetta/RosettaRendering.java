package io.github.malteas.rosetta;

import net.minecraft.class_2960;
import net.minecraft.class_332;

public final class RosettaRendering {

    private RosettaRendering() {}

    public static void renderTexture(class_332 g, class_2960 tex, int x, int y, int w, int h) {
        //? if >=1.21.6 {
        g.method_70845(tex, x, y, x + w, y + h, 0f, 1f, 0f, 1f);
        //?} elif >=1.21.2 {
        /*g.blit(RenderType::guiTextured, tex, x, y, 0f, 0f, w, h, w, h);*/
        //?} else {
        /*g.blit(tex, x, y, 0f, 0f, w, h, w, h);*/
        //?}
    }
}
