//? if fabric {
package io.github.malteas.rosetta.fabric;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.malteas.rosetta.Rosetta;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import java.util.concurrent.CompletableFuture;

public final class RosettaCommands {

    private RosettaCommands() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("rosetta")
                .then(ClientCommandManager.literal("reset")
                    .executes(RosettaCommands::resetAll)
                    .then(ClientCommandManager.argument("id", StringArgumentType.greedyString())
                        .suggests(RosettaCommands::suggestCards)
                        .executes(RosettaCommands::resetOne)))
                .then(ClientCommandManager.literal("show")
                    .then(ClientCommandManager.argument("id", StringArgumentType.greedyString())
                        .suggests(RosettaCommands::suggestCards)
                        .executes(RosettaCommands::show)))
                .then(ClientCommandManager.literal("list")
                    .executes(RosettaCommands::list))
                .then(ClientCommandManager.literal("replay")
                    .executes(RosettaCommands::replay))));
    }

    private static int resetAll(CommandContext<FabricClientCommandSource> ctx) {
        Rosetta.forgetAll();
        ctx.getSource().sendFeedback(class_2561.method_43470("[rosetta] Reset all card state."));
        return 1;
    }

    private static int resetOne(CommandContext<FabricClientCommandSource> ctx) {
        class_2960 id = parseId(ctx);
        if (id == null) return 0;
        Rosetta.forget(id);
        ctx.getSource().sendFeedback(class_2561.method_43470("[rosetta] Reset " + id + "."));
        return 1;
    }

    private static int show(CommandContext<FabricClientCommandSource> ctx) {
        class_2960 id = parseId(ctx);
        if (id == null) return 0;
        if (Rosetta.get(id).isEmpty()) {
            ctx.getSource().sendError(class_2561.method_43470("[rosetta] No card registered with id " + id));
            return 0;
        }
        Rosetta.defer(() -> Rosetta.show(id));
        return 1;
    }

    private static int replay(CommandContext<FabricClientCommandSource> ctx) {
        Rosetta.defer(Rosetta::openReplayScreen);
        return 1;
    }

    private static int list(CommandContext<FabricClientCommandSource> ctx) {
        var registered = Rosetta.registered();
        if (registered.isEmpty()) {
            ctx.getSource().sendFeedback(class_2561.method_43470("[rosetta] No cards registered."));
            return 1;
        }
        ctx.getSource().sendFeedback(class_2561.method_43470("[rosetta] Registered cards (" + registered.size() + "):"));
        for (class_2960 id : registered.keySet()) {
            String marker = Rosetta.isSeen(id) ? " [seen]" : "";
            ctx.getSource().sendFeedback(class_2561.method_43470("  - " + id + marker));
        }
        return 1;
    }

    private static CompletableFuture<Suggestions> suggestCards(CommandContext<FabricClientCommandSource> ctx, SuggestionsBuilder builder) {
        for (class_2960 id : Rosetta.registered().keySet()) {
            String s = id.toString();
            if (s.startsWith(builder.getRemaining()) || s.contains(builder.getRemaining())) {
                builder.suggest(s);
            }
        }
        return builder.buildFuture();
    }

    private static class_2960 parseId(CommandContext<FabricClientCommandSource> ctx) {
        String raw = StringArgumentType.getString(ctx, "id");
        class_2960 id = class_2960.method_12829(raw);
        if (id == null) {
            ctx.getSource().sendError(class_2561.method_43470("[rosetta] Invalid identifier: " + raw));
        }
        return id;
    }
}
//?}
