package io.github.malteas.rosetta.trigger;

import io.github.malteas.rosetta.Rosetta;
import net.minecraft.class_2960;

public final class TriggerContext {

    private final class_2960 cardId;

    public TriggerContext(class_2960 cardId) {
        this.cardId = cardId;
    }

    public class_2960 cardId() {
        return cardId;
    }

    public void fire() {
        Rosetta.showIfUnseen(cardId);
    }
}
