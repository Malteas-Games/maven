package io.github.malteas.rosetta;

import net.minecraft.class_304;
import net.minecraft.class_3675;

public final class RosettaKeys {

    //? if >=1.21.9 {
    /*private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            ResourceLocation.fromNamespaceAndPath("rosetta", "keys")
    );

    public static final KeyMapping NOTIFICATIONS = new KeyMapping(
            "key.rosetta.notifications",
            InputConstants.KEY_N,
            CATEGORY
    );
    *///?} else {
    public static final class_304 NOTIFICATIONS = new class_304(
            "key.rosetta.notifications",
            class_3675.field_32028,
            "key.categories.rosetta"
    );
    //?}

    private RosettaKeys() {}
}
