package io.github.malteas.rosetta.ui;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaNotification;
import io.github.malteas.rosetta.RosettaRendering;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class NotificationScreen extends class_437 {

    private static final int ENTRY_WIDTH = 320;
    private static final int ENTRY_HEIGHT = 24;
    private static final int ENTRY_GAP = 2;
    private static final int ICON_SIZE = 16;
    private static final int ICON_GAP = 4;
    private static final int BUTTON_WIDTH = 80;
    private static final int TOP_MARGIN = 40;
    private static final int TITLE_COLOR = 0xFFFFFFFF;
    private static final int MESSAGE_COLOR = 0xFFFFFFFF;
    private static final int BG_COLOR = 0xCC000000;

    private final class_437 parent;

    public NotificationScreen(class_437 parent) {
        super(class_2561.method_43471("rosetta.notifications.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        // Auto-dismiss simple notifications (no Show action) on screen open
        Rosetta.pendingNotifications().stream()
                .filter(n -> !n.hasShowAction())
                .map(RosettaNotification::id)
                .toList()
                .forEach(Rosetta::dismissNotification);

        List<RosettaNotification> notifications = new ArrayList<>(Rosetta.pendingNotifications());
        int x = (this.field_22789 - ENTRY_WIDTH) / 2;
        int y = TOP_MARGIN;

        for (RosettaNotification notif : notifications) {
            if (notif.hasShowAction()) {
                int buttonX = x + ENTRY_WIDTH - BUTTON_WIDTH;
                method_37063(class_4185.method_46430(notif.showLabel(), b -> {
                    Rosetta.dismissNotification(notif.id());
                    notif.onShow().run();
                }).method_46433(buttonX, y + 2).method_46432(BUTTON_WIDTH).method_46431());
            }

            y += ENTRY_HEIGHT + ENTRY_GAP;
        }

        y += 12;
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), b -> method_25419())
                .method_46433((this.field_22789 - 100) / 2, y).method_46432(100).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 16, TITLE_COLOR);

        List<RosettaNotification> notifications = Rosetta.pendingNotifications();
        if (notifications.isEmpty()) {
            graphics.method_27534(this.field_22793, class_2561.method_43471("rosetta.notifications.empty"),
                    this.field_22789 / 2, TOP_MARGIN + 4, 0xFFAAAAAA);
            return;
        }

        int x = (this.field_22789 - ENTRY_WIDTH) / 2;
        int y = TOP_MARGIN;

        for (RosettaNotification notif : notifications) {
            graphics.method_25294(x, y, x + ENTRY_WIDTH, y + ENTRY_HEIGHT, BG_COLOR);

            int textX = x + 4;
            int textY = y + (ENTRY_HEIGHT - 9) / 2;

            class_2960 icon = notif.icon();
            if (icon != null) {
                int iconY = y + (ENTRY_HEIGHT - ICON_SIZE) / 2;
                RosettaRendering.renderTexture(graphics, icon, textX, iconY, ICON_SIZE, ICON_SIZE);
                textX += ICON_SIZE + ICON_GAP;
            }

            graphics.method_27535(this.field_22793, notif.message(), textX, textY, notif.color());
            y += ENTRY_HEIGHT + ENTRY_GAP;
        }
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }
}
