package io.github.malteas.rosetta.ui;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaKeys;
import io.github.malteas.rosetta.RosettaNotification;
import io.github.malteas.rosetta.RosettaRendering;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class NotificationHud {

    private static final int BAR_HEIGHT = 20;
    private static final int BAR_PADDING = 4;
    private static final int ICON_SIZE = 12;
    private static final int BG_COLOR = 0xCC000000;
    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int HINT_COLOR = 0xFFAAAAAA;

    private NotificationHud() {}

    public static void draw(class_332 graphics) {
        List<RosettaNotification> notifications = Rosetta.pendingNotifications();
        if (notifications.isEmpty()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null) return;

        class_327 font = mc.field_1772;
        int screenWidth = mc.method_22683().method_4486();

        RosettaNotification latest = notifications.get(notifications.size() - 1);
        String keyName = RosettaKeys.NOTIFICATIONS.method_16007().getString();

        class_2561 messageText;
        if (notifications.size() == 1) {
            messageText = latest.message();
        } else {
            messageText = class_2561.method_43470(notifications.size() + " notifications");
        }

        class_2561 hint = class_2561.method_43470(" - Press [" + keyName + "]");
        int messageWidth = font.method_27525(messageText);
        int hintWidth = font.method_27525(hint);
        int iconSpace = latest.icon() != null ? ICON_SIZE + BAR_PADDING : 0;
        int totalWidth = BAR_PADDING + iconSpace + messageWidth + hintWidth + BAR_PADDING;

        int barLeft = (screenWidth - totalWidth) / 2;
        int barTop = 4;

        graphics.method_25294(barLeft, barTop, barLeft + totalWidth, barTop + BAR_HEIGHT, BG_COLOR);

        int x = barLeft + BAR_PADDING;
        int textY = barTop + (BAR_HEIGHT - 9) / 2;

        if (latest.icon() != null) {
            int iconY = barTop + (BAR_HEIGHT - ICON_SIZE) / 2;
            RosettaRendering.renderTexture(graphics, latest.icon(), x, iconY, ICON_SIZE, ICON_SIZE);
            x += ICON_SIZE + BAR_PADDING;
        }

        graphics.method_27535(font, messageText, x, textY, latest.color());
        x += messageWidth;
        graphics.method_27535(font, hint, x, textY, HINT_COLOR);
    }
}
