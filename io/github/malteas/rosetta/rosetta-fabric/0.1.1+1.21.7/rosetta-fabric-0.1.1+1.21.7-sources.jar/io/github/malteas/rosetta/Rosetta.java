package io.github.malteas.rosetta;

import io.github.malteas.rosetta.trigger.RosettaTrigger;
import io.github.malteas.rosetta.trigger.TriggerContext;
import io.github.malteas.rosetta.ui.NotificationScreen;
import io.github.malteas.rosetta.ui.RosettaReplayScreen;
import io.github.malteas.rosetta.ui.RosettaScreen;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class Rosetta {

    private static final Map<class_2960, RosettaOnboardCard> REGISTRY = new HashMap<>();
    private static final Deque<class_2960> PENDING = new ArrayDeque<>();
    private static final Set<class_2960> PENDING_SET = new LinkedHashSet<>();
    private static final List<RosettaNotification> NOTIFICATIONS = new ArrayList<>();
    private static Runnable deferredAction;

    private Rosetta() {}

    public static void register(RosettaOnboardCard card) {
        Objects.requireNonNull(card, "card must not be null");
        REGISTRY.put(card.id(), card);
        RosettaTrigger trigger = card.trigger();
        if (trigger != null) {
            trigger.register(new TriggerContext(card.id()));
        }
    }

    public static Optional<RosettaOnboardCard> get(class_2960 id) {
        return Optional.ofNullable(REGISTRY.get(id));
    }

    public static Map<class_2960, RosettaOnboardCard> registered() {
        return Collections.unmodifiableMap(REGISTRY);
    }

    public static boolean isSeen(class_2960 id) {
        RosettaOnboardCard card = REGISTRY.get(id);
        if (card == null) return false;
        return RosettaPersistence.get().isSeen(id, card.version());
    }

    public static void markSeen(class_2960 id) {
        RosettaOnboardCard card = REGISTRY.get(id);
        if (card == null) return;
        RosettaPersistence.get().markSeen(id, card.version());
    }

    public static void forget(class_2960 id) {
        RosettaPersistence.get().forget(id);
    }

    public static void forgetAll() {
        RosettaPersistence.get().forgetAll();
    }

    public static void showIfUnseen(class_2960 id) {
        if (isSeen(id)) return;
        enqueue(id);
    }

    public static void show(class_2960 id) {
        showScreen(id, null);
    }

    private static void showScreen(class_2960 id, Runnable closeCallback) {
        RosettaOnboardCard card = REGISTRY.get(id);
        if (card == null) return;
        class_310 mc = class_310.method_1551();
        mc.method_1507(new RosettaScreen(card, mc.field_1755, closeCallback));
    }

    public static void notify(RosettaNotification notification) {
        Objects.requireNonNull(notification, "notification must not be null");
        NOTIFICATIONS.add(notification);
        if (notification.playSound()) {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 != null) {
                mc.field_1724.method_5783(net.minecraft.class_3417.field_14561, 1.0f, 1.0f);
            }
        }
    }

    public static List<RosettaNotification> pendingNotifications() {
        return Collections.unmodifiableList(NOTIFICATIONS);
    }

    public static void dismissNotification(class_2960 id) {
        NOTIFICATIONS.removeIf(n -> n.id().equals(id));
    }

    public static void openNotificationScreen() {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new NotificationScreen(mc.field_1755));
    }

    public static void openReplayScreen() {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new RosettaReplayScreen(mc.field_1755));
    }

    static void enqueue(class_2960 id) {
        if (!REGISTRY.containsKey(id)) return;
        if (!PENDING_SET.add(id)) return;
        PENDING.addLast(id);
    }

    /** Card ids currently queued for display, in display order. */
    public static List<class_2960> pendingCardIds() {
        return List.copyOf(PENDING);
    }

    // Test seam: clears all static state so tests can run in isolation.
    static void resetForTesting() {
        REGISTRY.clear();
        PENDING.clear();
        PENDING_SET.clear();
        NOTIFICATIONS.clear();
        deferredAction = null;
    }

    public static void defer(Runnable action) {
        deferredAction = action;
    }

    public static boolean isSafeToShow() {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) return false;
        if (player.method_29504()) return false;
        if (player.method_6113()) return false;
        if (player.method_6128()) return false;
        if (player.method_7325()) return false;
        if (player.field_6235 > 0) return false;
        return true;
    }

    public static void drainPending() {
        class_310 mc = class_310.method_1551();
        if (deferredAction != null && mc.field_1755 == null) {
            Runnable action = deferredAction;
            deferredAction = null;
            action.run();
            return;
        }
        if (PENDING.isEmpty()) return;
        if (mc.field_1755 != null) return;
        if (!isSafeToShow()) return;

        List<RosettaOnboardCard> cards = new ArrayList<>();
        while (!PENDING.isEmpty()) {
            class_2960 id = PENDING.pollFirst();
            PENDING_SET.remove(id);
            RosettaOnboardCard card = REGISTRY.get(id);
            if (card != null) {
                cards.add(card);
            }
        }
        if (cards.isEmpty()) return;

        mc.method_1507(new RosettaScreen(cards, 0, null, true));
    }
}
