package io.github.malteas.rosetta.ui;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaOnboardCard;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class RosettaScreen extends class_437 {

    private static final int CARD_PADDING = 16;
    private static final int BUTTON_HEIGHT = 20;
    private static final int NAV_BUTTON_WIDTH = 80;
    private static final int DONE_BUTTON_WIDTH = 100;
    private static final int COUNTER_COLOR = 0xFFAAAAAA;

    private final List<RosettaOnboardCard> cards;
    private final int currentIndex;
    private final class_437 parent;
    private final boolean markSeenOnNav;
    private final Runnable closeCallback;

    private boolean playedOpenSound;
    private int cardWidth;
    private int cardLeft;
    private int cardTop;
    private int cardHeight;
    private int contentHeight;
    private int buttonY;

    public RosettaScreen(RosettaOnboardCard card, class_437 parent, Runnable closeCallback) {
        super(card.title());
        this.cards = List.of(card);
        this.currentIndex = 0;
        this.parent = parent;
        this.markSeenOnNav = false;
        this.closeCallback = closeCallback;
    }

    public RosettaScreen(List<RosettaOnboardCard> cards, int index, class_437 parent, boolean markSeenOnNav) {
        super(cards.get(index).title());
        this.cards = cards;
        this.currentIndex = index;
        this.parent = parent;
        this.markSeenOnNav = markSeenOnNav;
        this.closeCallback = null;
    }

    private RosettaOnboardCard card() {
        return cards.get(currentIndex);
    }

    @Override
    protected void method_25426() {
        if (!playedOpenSound && card().playAudio() && this.field_22787.field_1724 != null) {
            playedOpenSound = true;
            this.field_22787.field_1724.method_5783(class_3417.field_14561, 1.0f, 1.0f);
        }

        RosettaOnboardCard card = card();
        this.cardWidth = card.measureWidth();
        int contentWidth = cardWidth - 2 * CARD_PADDING;
        this.contentHeight = card.measureHeight(this.field_22793, contentWidth);
        this.cardHeight = 3 * CARD_PADDING + contentHeight + BUTTON_HEIGHT;
        this.cardLeft = (this.field_22789 - cardWidth) / 2;
        this.cardTop = (this.field_22790 - cardHeight) / 2;

        this.buttonY = cardTop + 2 * CARD_PADDING + contentHeight;

        card.addWidgets(this::method_37063, this.field_22793,
                cardLeft + CARD_PADDING, cardTop + CARD_PADDING,
                contentWidth, contentHeight);

        if (cards.size() > 1) {
            int navLeft = cardLeft + CARD_PADDING;
            int navRight = cardLeft + cardWidth - CARD_PADDING;

            if (currentIndex > 0) {
                method_37063(class_4185.method_46430(
                                class_2561.method_43471("rosetta.back"), b -> goBack())
                        .method_46433(navLeft, buttonY).method_46432(NAV_BUTTON_WIDTH).method_46431());
            }

            boolean isLast = currentIndex == cards.size() - 1;
            class_2561 label = isLast
                    ? class_2561.method_43471("rosetta.done")
                    : class_2561.method_43471("rosetta.next");
            method_37063(class_4185.method_46430(label, b -> {
                        if (isLast) method_25419(); else goNext();
                    })
                    .method_46433(navRight - NAV_BUTTON_WIDTH, buttonY).method_46432(NAV_BUTTON_WIDTH).method_46431());
        } else {
            method_37063(class_4185.method_46430(
                            class_2561.method_43471("rosetta.done"), b -> method_25419())
                    .method_46433((this.field_22789 - DONE_BUTTON_WIDTH) / 2, buttonY)
                    .method_46432(DONE_BUTTON_WIDTH).method_46431());
        }
    }

    @Override
    public void method_25420(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25420(graphics, mouseX, mouseY, partialTick);
        RosettaOnboardCard card = card();
        card.drawBackground(graphics, cardLeft, cardTop, cardWidth, cardHeight);
        card.drawContent(graphics, this.field_22793,
                cardLeft + CARD_PADDING, cardTop + CARD_PADDING,
                cardWidth - 2 * CARD_PADDING, contentHeight);

        if (cards.size() > 1) {
            String counter = (currentIndex + 1) + " / " + cards.size();
            graphics.method_25300(this.field_22793, counter, this.field_22789 / 2, buttonY + 6, COUNTER_COLOR);
        }
    }

    private void goNext() {
        if (markSeenOnNav) {
            Rosetta.markSeen(card().id());
        }
        this.field_22787.method_1507(new RosettaScreen(cards, currentIndex + 1, parent, markSeenOnNav));
    }

    private void goBack() {
        this.field_22787.method_1507(new RosettaScreen(cards, currentIndex - 1, parent, markSeenOnNav));
    }

    @Override
    public void method_25419() {
        if (card().playAudio() && this.field_22787.field_1724 != null) {
            this.field_22787.field_1724.method_5783(class_3417.field_14641, 1.0f, 1.0f);
        }
        if (markSeenOnNav) {
            Rosetta.markSeen(card().id());
        }
        if (closeCallback != null) {
            closeCallback.run();
        }
        this.field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
