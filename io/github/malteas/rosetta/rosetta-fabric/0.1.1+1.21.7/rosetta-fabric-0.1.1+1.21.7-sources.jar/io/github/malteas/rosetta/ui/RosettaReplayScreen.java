package io.github.malteas.rosetta.ui;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaOnboardCard;
import io.github.malteas.rosetta.RosettaRendering;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class RosettaReplayScreen extends class_437 {

    private static final int BUTTON_WIDTH = 260;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 4;
    private static final int TOP_MARGIN = 40;
    private static final int ICON_SIZE = 16;
    private static final int ICON_GAP = 4;
    private static final int TITLE_COLOR = 0xFFFFFFFF;
    private static final int DIM_COLOR = 0xFFAAAAAA;

    private final class_437 parent;
    private final List<IconEntry> iconEntries = new ArrayList<>();

    private record IconEntry(class_2960 texture, int x, int y) {}

    public RosettaReplayScreen(class_437 parent) {
        super(class_2561.method_43471("rosetta.replay.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        iconEntries.clear();

        Map<class_2960, RosettaOnboardCard> registered = Rosetta.registered();
        List<class_2960> ids = new ArrayList<>(registered.keySet());
        ids.sort(Comparator.comparing(class_2960::toString));

        int x = (this.field_22789 - BUTTON_WIDTH) / 2;
        int y = TOP_MARGIN;

        for (class_2960 id : ids) {
            RosettaOnboardCard card = registered.get(id);
            class_2960 icon = card.icon();
            if (icon != null) {
                iconEntries.add(new IconEntry(icon, x - ICON_SIZE - ICON_GAP, y + (BUTTON_HEIGHT - ICON_SIZE) / 2));
            }
            method_37063(class_4185.method_46430(card.title(), button -> Rosetta.show(id))
                    .method_46433(x, y)
                    .method_46432(BUTTON_WIDTH)
                    .method_46431());
            y += BUTTON_HEIGHT + BUTTON_GAP;
        }

        y += BUTTON_GAP + 8;

        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), button -> method_25419())
                .method_46433(x, y)
                .method_46432(BUTTON_WIDTH)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 16, TITLE_COLOR);

        for (IconEntry entry : iconEntries) {
            RosettaRendering.renderTexture(graphics, entry.texture(), entry.x(), entry.y(), ICON_SIZE, ICON_SIZE);
        }

        if (Rosetta.registered().isEmpty()) {
            graphics.method_27534(
                    this.field_22793,
                    class_2561.method_43471("rosetta.replay.empty"),
                    this.field_22789 / 2,
                    TOP_MARGIN + 4,
                    DIM_COLOR);
        }
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }
}
