package io.github.malteas.rosetta;

import io.github.malteas.rosetta.trigger.RosettaTrigger;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

public interface RosettaOnboardCard {

    class_2960 id();

    class_2561 title();

    CardCategory category();

    RosettaTrigger trigger();

    int version();

    default class_2960 icon() {
        return null;
    }

    default int measureWidth() {
        return 300;
    }

    int measureHeight(class_327 font, int contentWidth);

    void drawContent(class_332 graphics, class_327 font, int left, int top, int width, int height);

    default boolean playAudio() {
        return true;
    }

    default void drawBackground(class_332 graphics, int left, int top, int width, int height) {
        graphics.method_25294(left, top, left + width, top + height, 0xCC000000);
    }

    default void addWidgets(java.util.function.Consumer<net.minecraft.class_339> adder,
                            class_327 font, int contentLeft, int contentTop, int contentWidth, int contentHeight) {}
}
