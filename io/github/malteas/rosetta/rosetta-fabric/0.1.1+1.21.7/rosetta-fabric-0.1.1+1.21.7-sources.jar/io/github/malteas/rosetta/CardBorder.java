package io.github.malteas.rosetta;

import net.minecraft.class_2960;
import net.minecraft.class_332;

public interface CardBorder {

    void draw(class_332 graphics, int left, int top, int width, int height);

    int inset();

    static CardBorder solid(int color) {
        return solid(color, 1);
    }

    static CardBorder solid(int color, int thickness) {
        return new CardBorder() {
            @Override
            public void draw(class_332 g, int left, int top, int width, int height) {
                int r = left + width;
                int b = top + height;
                int t = thickness;
                g.method_25294(left, top, r, top + t, color);
                g.method_25294(left, b - t, r, b, color);
                g.method_25294(left, top + t, left + t, b - t, color);
                g.method_25294(r - t, top + t, r, b - t, color);
            }

            @Override
            public int inset() {
                return thickness;
            }
        };
    }

    static CardBorder texture(class_2960 tex, int cornerSize) {
        return new CardBorder() {
            @Override
            public void draw(class_332 g, int left, int top, int width, int height) {
                NineSliceRenderer.drawNineSlice(g, tex, left, top, width, height, cornerSize);
            }

            @Override
            public int inset() {
                return cornerSize;
            }
        };
    }
}
