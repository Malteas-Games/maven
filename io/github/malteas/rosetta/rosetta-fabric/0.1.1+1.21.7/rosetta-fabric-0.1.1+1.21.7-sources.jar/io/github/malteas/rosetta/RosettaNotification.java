package io.github.malteas.rosetta;

import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class RosettaNotification {

    private final class_2960 id;
    private final class_2561 message;
    private class_2960 icon;
    private int color = 0xFFFFFFFF;
    private boolean playSound = true;
    private Runnable onShow;
    private class_2561 showLabel;

    public RosettaNotification(class_2960 id, class_2561 message) {
        this.id = Objects.requireNonNull(id);
        this.message = Objects.requireNonNull(message);
    }

    public RosettaNotification icon(class_2960 icon) {
        this.icon = icon;
        return this;
    }

    public RosettaNotification color(int argb) {
        this.color = argb;
        return this;
    }

    public RosettaNotification noSound() {
        this.playSound = false;
        return this;
    }

    public RosettaNotification onShow(class_2561 label, Runnable action) {
        this.showLabel = Objects.requireNonNull(label);
        this.onShow = Objects.requireNonNull(action);
        return this;
    }

    public class_2960 id() { return id; }
    public class_2561 message() { return message; }
    public class_2960 icon() { return icon; }
    public int color() { return color; }
    public boolean playSound() { return playSound; }
    public Runnable onShow() { return onShow; }
    public class_2561 showLabel() { return showLabel; }
    public boolean hasShowAction() { return onShow != null; }
}
