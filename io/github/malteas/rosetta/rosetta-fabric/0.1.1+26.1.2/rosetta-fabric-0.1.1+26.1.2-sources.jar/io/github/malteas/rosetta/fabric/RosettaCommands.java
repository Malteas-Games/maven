//? if fabric {
package io.github.malteas.rosetta.fabric;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.malteas.rosetta.Rosetta;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.concurrent.CompletableFuture;

public final class RosettaCommands {

    private RosettaCommands() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommands.literal("rosetta")
                .then(ClientCommands.literal("reset")
                    .executes(RosettaCommands::resetAll)
                    .then(ClientCommands.argument("id", StringArgumentType.greedyString())
                        .suggests(RosettaCommands::suggestCards)
                        .executes(RosettaCommands::resetOne)))
                .then(ClientCommands.literal("show")
                    .then(ClientCommands.argument("id", StringArgumentType.greedyString())
                        .suggests(RosettaCommands::suggestCards)
                        .executes(RosettaCommands::show)))
                .then(ClientCommands.literal("list")
                    .executes(RosettaCommands::list))
                .then(ClientCommands.literal("replay")
                    .executes(RosettaCommands::replay))));
    }

    private static int resetAll(CommandContext<FabricClientCommandSource> ctx) {
        Rosetta.forgetAll();
        ctx.getSource().sendFeedback(Component.literal("[rosetta] Reset all card state."));
        return 1;
    }

    private static int resetOne(CommandContext<FabricClientCommandSource> ctx) {
        Identifier id = parseId(ctx);
        if (id == null) return 0;
        Rosetta.forget(id);
        ctx.getSource().sendFeedback(Component.literal("[rosetta] Reset " + id + "."));
        return 1;
    }

    private static int show(CommandContext<FabricClientCommandSource> ctx) {
        Identifier id = parseId(ctx);
        if (id == null) return 0;
        if (Rosetta.get(id).isEmpty()) {
            ctx.getSource().sendError(Component.literal("[rosetta] No card registered with id " + id));
            return 0;
        }
        Rosetta.defer(() -> Rosetta.show(id));
        return 1;
    }

    private static int replay(CommandContext<FabricClientCommandSource> ctx) {
        Rosetta.defer(Rosetta::openReplayScreen);
        return 1;
    }

    private static int list(CommandContext<FabricClientCommandSource> ctx) {
        var registered = Rosetta.registered();
        if (registered.isEmpty()) {
            ctx.getSource().sendFeedback(Component.literal("[rosetta] No cards registered."));
            return 1;
        }
        ctx.getSource().sendFeedback(Component.literal("[rosetta] Registered cards (" + registered.size() + "):"));
        for (Identifier id : registered.keySet()) {
            String marker = Rosetta.isSeen(id) ? " [seen]" : "";
            ctx.getSource().sendFeedback(Component.literal("  - " + id + marker));
        }
        return 1;
    }

    private static CompletableFuture<Suggestions> suggestCards(CommandContext<FabricClientCommandSource> ctx, SuggestionsBuilder builder) {
        for (Identifier id : Rosetta.registered().keySet()) {
            String s = id.toString();
            if (s.startsWith(builder.getRemaining()) || s.contains(builder.getRemaining())) {
                builder.suggest(s);
            }
        }
        return builder.buildFuture();
    }

    private static Identifier parseId(CommandContext<FabricClientCommandSource> ctx) {
        String raw = StringArgumentType.getString(ctx, "id");
        Identifier id = Identifier.tryParse(raw);
        if (id == null) {
            ctx.getSource().sendError(Component.literal("[rosetta] Invalid identifier: " + raw));
        }
        return id;
    }
}
//?}
