package io.github.malteas.rosetta;

import io.github.malteas.rosetta.trigger.RosettaTrigger;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

public class SimpleCard implements RosettaOnboardCard {

    private static final int TITLE_ICON_SIZE = 16;
    private static final int TITLE_ICON_GAP = 4;
    private static final float TITLE_SCALE = 1.5f;
    private static final int TITLE_HEIGHT = (int)(9 * TITLE_SCALE);
    private static final int TITLE_BOTTOM_GAP = 8;
    private static final int LINE_HEIGHT = 9;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 4;
    private static final int BUTTON_TOP_GAP = 8;

    private static final int SEP_PADDING = 4;
    private static final int SEP_HEIGHT = 1;
    private static final int SEP_COLOR = 0xFF555555;

    private static final int TITLE_COLOR = 0xFFFFFF00;
    private static final int TEXT_COLOR = 0xFFFFFFFF;

    private final Identifier id;
    private final Component title;
    private final CardCategory category;
    private final RosettaTrigger trigger;

    private Identifier icon;
    private Identifier background;
    private final List<ContentItem> content = new ArrayList<>();

    private sealed interface ContentItem {}
    private record TextItem(Component message) implements ContentItem {}
    private record SeparatorItem() implements ContentItem {}
    private int version = 1;
    private int cardWidth = 300;
    private int overlayColor = 0x80000000;
    private CardBorder border;
    private boolean audio = true;
    private final List<CardButton> buttons = new ArrayList<>();

    private record CardButton(Component label, Runnable onClick) {}

    public SimpleCard(Identifier id, Component title, CardCategory category, RosettaTrigger trigger) {
        this.id = Objects.requireNonNull(id, "SimpleCard.id must not be null");
        this.title = Objects.requireNonNull(title, "SimpleCard.title must not be null");
        this.category = Objects.requireNonNull(category, "SimpleCard.category must not be null");
        this.trigger = trigger;
    }

    public SimpleCard addIcon(Identifier icon) {
        this.icon = Objects.requireNonNull(icon, "icon must not be null");
        return this;
    }

    public SimpleCard addBackground(Identifier background) {
        this.background = Objects.requireNonNull(background, "background must not be null");
        return this;
    }

    public SimpleCard addText(Component text) {
        this.content.add(new TextItem(Objects.requireNonNull(text, "text must not be null")));
        return this;
    }

    public SimpleCard addSep() {
        this.content.add(new SeparatorItem());
        return this;
    }

    public SimpleCard addButton(Component label, Runnable onClick) {
        this.buttons.add(new CardButton(
                Objects.requireNonNull(label, "label must not be null"),
                Objects.requireNonNull(onClick, "onClick must not be null")));
        return this;
    }

    public SimpleCard version(int version) {
        this.version = version;
        return this;
    }

    public SimpleCard width(int width) {
        this.cardWidth = width;
        return this;
    }

    public SimpleCard overlay(int argbColor) {
        this.overlayColor = argbColor;
        return this;
    }

    public SimpleCard border(CardBorder border) {
        this.border = border;
        return this;
    }

    public SimpleCard noSound() {
        this.audio = false;
        return this;
    }

    @Override
    public boolean playAudio() {
        return audio;
    }

    @Override
    public int measureWidth() {
        return cardWidth;
    }

    @Override public Identifier id() { return id; }
    @Override public Component title() { return title; }
    @Override public CardCategory category() { return category; }
    @Override public RosettaTrigger trigger() { return trigger; }
    @Override public int version() { return version; }
    @Override public Identifier icon() { return icon; }

    @Override
    public int measureHeight(Font font, int contentWidth) {
        int h = 0;
        int titleH = icon != null ? Math.max(TITLE_ICON_SIZE, TITLE_HEIGHT) : TITLE_HEIGHT;
        h += titleH + TITLE_BOTTOM_GAP;
        for (ContentItem item : content) {
            switch (item) {
                case TextItem t -> h += font.split(t.message(), contentWidth).size() * LINE_HEIGHT;
                case SeparatorItem ignored -> h += SEP_PADDING + SEP_HEIGHT + SEP_PADDING;
            }
        }
        if (!buttons.isEmpty()) {
            h += BUTTON_TOP_GAP;
            h += buttons.size() * BUTTON_HEIGHT + (buttons.size() - 1) * BUTTON_GAP;
        }
        return h;
    }

    @Override
    public void drawBackground(GuiGraphicsExtractor graphics, int left, int top, int width, int height) {
        if (background != null) {
            RosettaRendering.renderTexture(graphics, background, left, top, width, height);
        }
        graphics.fill(left, top, left + width, top + height, overlayColor);
        if (border != null) {
            border.draw(graphics, left, top, width, height);
        }
    }

    @Override
    public void drawContent(GuiGraphicsExtractor graphics, Font font, int left, int top, int width, int height) {
        int y = top;
        int centerX = left + width / 2;

        int scaledTitleWidth = (int)(font.width(title) * TITLE_SCALE);
        int titleH;

        if (icon != null) {
            int totalWidth = TITLE_ICON_SIZE + TITLE_ICON_GAP + scaledTitleWidth;
            int startX = centerX - totalWidth / 2;
            int iconY = y + (TITLE_HEIGHT - TITLE_ICON_SIZE) / 2 - 3;
            RosettaRendering.renderTexture(graphics, icon, startX, iconY, TITLE_ICON_SIZE, TITLE_ICON_SIZE);
            int textX = startX + TITLE_ICON_SIZE + TITLE_ICON_GAP;
            drawScaledString(graphics, font, title, textX, y, TITLE_COLOR);
            titleH = Math.max(TITLE_ICON_SIZE, TITLE_HEIGHT);
        } else {
            drawScaledCenteredString(graphics, font, title, centerX, y, TITLE_COLOR);
            titleH = TITLE_HEIGHT;
        }

        y += titleH + TITLE_BOTTOM_GAP;

        for (ContentItem item : content) {
            switch (item) {
                case TextItem t -> {
                    int lines = font.split(t.message(), width).size();
                    graphics.textWithWordWrap(font, t.message(), left, y, width, TEXT_COLOR);
                    y += lines * LINE_HEIGHT;
                }
                case SeparatorItem ignored -> {
                    y += SEP_PADDING;
                    graphics.fill(left, y, left + width, y + SEP_HEIGHT, SEP_COLOR);
                    y += SEP_HEIGHT + SEP_PADDING;
                }
            }
        }
    }

    @Override
    public void addWidgets(Consumer<AbstractWidget> adder, Font font, int left, int top, int width, int height) {
        if (buttons.isEmpty()) return;

        int y = top + contentOffsetBeforeButtons(font, width);

        for (CardButton btn : buttons) {
            adder.accept(Button.builder(btn.label(), b -> btn.onClick().run())
                    .pos(left, y)
                    .width(width)
                    .build());
            y += BUTTON_HEIGHT + BUTTON_GAP;
        }
    }

    private void drawScaledString(GuiGraphicsExtractor g, Font font, Component text, int x, int y, int color) {
        g.pose().pushMatrix();
        //? if >=1.21.6 {
        g.pose().scale(TITLE_SCALE, TITLE_SCALE);
        //?} else {
        /*g.pose().scale(TITLE_SCALE, TITLE_SCALE, 1f);*/
        //?}
        g.text(font, text, (int)(x / TITLE_SCALE), (int)(y / TITLE_SCALE), color);
        g.pose().popMatrix();
    }

    private void drawScaledCenteredString(GuiGraphicsExtractor g, Font font, Component text, int cx, int y, int color) {
        g.pose().pushMatrix();
        //? if >=1.21.6 {
        g.pose().scale(TITLE_SCALE, TITLE_SCALE);
        //?} else {
        /*g.pose().scale(TITLE_SCALE, TITLE_SCALE, 1f);*/
        //?}
        g.centeredText(font, text, (int)(cx / TITLE_SCALE), (int)(y / TITLE_SCALE), color);
        g.pose().popMatrix();
    }

    private int contentOffsetBeforeButtons(Font font, int contentWidth) {
        int y = 0;
        int titleH = icon != null ? Math.max(TITLE_ICON_SIZE, TITLE_HEIGHT) : TITLE_HEIGHT;
        y += titleH + TITLE_BOTTOM_GAP;
        for (ContentItem item : content) {
            switch (item) {
                case TextItem t -> y += font.split(t.message(), contentWidth).size() * LINE_HEIGHT;
                case SeparatorItem ignored -> y += SEP_PADDING + SEP_HEIGHT + SEP_PADDING;
            }
        }
        y += BUTTON_TOP_GAP;
        return y;
    }
}
