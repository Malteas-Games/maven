package io.github.malteas.rosetta;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
//? if fabric {
import net.fabricmc.loader.api.FabricLoader;
//?} elif neoforge {
/*import net.neoforged.fml.loading.FMLPaths;*/
//?}
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

final class RosettaPersistence {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static RosettaPersistence instance;

    private final Path path;
    private final Map<Identifier, Integer> seen = new HashMap<>();

    private RosettaPersistence(Path path) {
        this.path = path;
    }

    static RosettaPersistence get() {
        if (instance == null) {
            //? if fabric {
            Path path = FabricLoader.getInstance().getConfigDir()
                    .resolve("rosetta")
                    .resolve("state.json");
            //?} elif neoforge {
            /*Path path = FMLPaths.CONFIGDIR.get()
                    .resolve("rosetta")
                    .resolve("state.json");*/
            //?}
            instance = new RosettaPersistence(path);
            instance.load();
        }
        return instance;
    }

    // Test seam: creates a persistence instance backed by an arbitrary path.
    static RosettaPersistence createForTesting(Path path) {
        RosettaPersistence p = new RosettaPersistence(path);
        p.load();
        return p;
    }

    // Test seam: overrides the singleton so tests don't touch the real config dir.
    static void setInstanceForTesting(RosettaPersistence p) {
        instance = p;
    }

    private void load() {
        if (!Files.exists(path)) return;
        try {
            String json = Files.readString(path);
            JsonObject root = GSON.fromJson(json, JsonObject.class);
            if (root == null) return;
            JsonObject seenObj = root.getAsJsonObject("seen");
            if (seenObj == null) return;
            for (Map.Entry<String, JsonElement> e : seenObj.entrySet()) {
                if (!e.getValue().isJsonPrimitive()) continue;
                Identifier id = Identifier.tryParse(e.getKey());
                if (id == null) continue;
                seen.put(id, e.getValue().getAsInt());
            }
        } catch (IOException | JsonSyntaxException | ClassCastException | IllegalStateException ex) {
            System.err.println("[rosetta] Failed to load " + path + ": " + ex.getMessage());
        }
    }

    private void save() {
        JsonObject root = new JsonObject();
        JsonObject seenObj = new JsonObject();
        for (Map.Entry<Identifier, Integer> e : seen.entrySet()) {
            seenObj.addProperty(e.getKey().toString(), e.getValue());
        }
        root.add("seen", seenObj);
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(root));
        } catch (IOException ex) {
            System.err.println("[rosetta] Failed to save " + path + ": " + ex.getMessage());
        }
    }

    boolean isSeen(Identifier id, int version) {
        Integer stored = seen.get(id);
        return stored != null && stored >= version;
    }

    void markSeen(Identifier id, int version) {
        Integer stored = seen.get(id);
        if (stored != null && stored >= version) return;
        seen.put(id, version);
        save();
    }

    void forget(Identifier id) {
        if (seen.remove(id) != null) {
            save();
        }
    }

    void forgetAll() {
        if (seen.isEmpty()) return;
        seen.clear();
        save();
    }
}
