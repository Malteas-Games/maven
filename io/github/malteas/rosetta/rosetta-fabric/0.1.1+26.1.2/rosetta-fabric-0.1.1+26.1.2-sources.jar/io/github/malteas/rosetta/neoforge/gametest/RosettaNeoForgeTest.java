//? if neoforge && >=1.21.9 {
/*
package io.github.malteas.rosetta.neoforge.gametest;

import net.minecraft.core.Holder;
import net.minecraft.gametest.framework.BuiltinTestFunctions;
import net.minecraft.gametest.framework.FunctionGameTestInstance;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.gametest.framework.TestData;
import net.minecraft.gametest.framework.TestEnvironmentDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Rotation;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterGameTestsEvent;

import java.util.List;

// Server-side gametests for Rosetta on NeoForge 1.21.9+.
// The gametest API was rewritten in 1.21.5 (TestInstance-based) — this class targets
// that API. Versions before 1.21.9 cannot run these tests at all: their FML enforces
// dist-stripping on the dedicated gametest server, and Rosetta (a client-side mod)
// references net.minecraft.client.* classes which then refuse to load.
//
// Run via `./gradlew :<version>-neoforge:runGameTestServer`. Exit code = number of
// failed required tests.
//
// Uses minecraft:empty — a 1x1x1 empty structure bundled with Minecraft 1.21.5+.
// No extra resource files needed.
//
// NOTE: raw types used for TestEnvironmentDefinition because 26.1 parameterized it
// as TestEnvironmentDefinition<?> while 1.21.5–1.21.11 left it unparameterized.
@EventBusSubscriber(modid = "rosetta")
@SuppressWarnings({"rawtypes", "unchecked"})
public class RosettaNeoForgeTest {

    private static class CheckTestInstance extends FunctionGameTestInstance {
        private final Runnable checks;

        CheckTestInstance(TestData info, Runnable checks) {
            super(BuiltinTestFunctions.ALWAYS_PASS, info);
            this.checks = checks;
        }

        @Override
        public void run(GameTestHelper helper) {
            checks.run();
            helper.succeed();
        }
    }

    @SubscribeEvent
    public static void onRegisterGameTests(RegisterGameTestsEvent event) {
        Holder env = event.registerEnvironment(
                Identifier.fromNamespaceAndPath("rosetta", "default"),
                new TestEnvironmentDefinition.AllOf(List.of())
        );
        TestData data = new TestData<>(
                env,
                Identifier.withDefaultNamespace("empty"),  // minecraft:empty, bundled with MC 1.21.5+
                20, 0, true, Rotation.NONE
        );

        event.registerTest(
                Identifier.fromNamespaceAndPath("rosetta", "card_registry_round_trip"),
                new CheckTestInstance(data, RosettaGametestChecks::cardRegistryRoundTrip)
        );
        event.registerTest(
                Identifier.fromNamespaceAndPath("rosetta", "seen_state_lifecycle"),
                new CheckTestInstance(data, RosettaGametestChecks::seenStateLifecycle)
        );
        event.registerTest(
                Identifier.fromNamespaceAndPath("rosetta", "trigger_enqueues_unseen_card_once"),
                new CheckTestInstance(data, RosettaGametestChecks::triggerEnqueuesUnseenCardOnce)
        );
        event.registerTest(
                Identifier.fromNamespaceAndPath("rosetta", "notification_inbox_lifecycle"),
                new CheckTestInstance(data, RosettaGametestChecks::notificationInboxLifecycle)
        );
    }
}
*///?}
