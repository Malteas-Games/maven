package io.github.malteas.rosetta.trigger;

import io.github.malteas.rosetta.Rosetta;
import net.minecraft.resources.Identifier;

public final class TriggerContext {

    private final Identifier cardId;

    public TriggerContext(Identifier cardId) {
        this.cardId = cardId;
    }

    public Identifier cardId() {
        return cardId;
    }

    public void fire() {
        Rosetta.showIfUnseen(cardId);
    }
}
