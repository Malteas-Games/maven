package io.github.malteas.rosetta;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

final class NineSliceRenderer {

    private NineSliceRenderer() {}

    static void drawNineSlice(GuiGraphicsExtractor g, Identifier tex, int x, int y, int w, int h, int corner) {
        int texW = w;
        int texH = h;
        int midW = w - 2 * corner;
        int midH = h - 2 * corner;

        // Corners
        blitRegion(g, tex, x, y, corner, corner, 0f, 0f, corner, corner, texW, texH);
        blitRegion(g, tex, x + w - corner, y, corner, corner, w - corner, 0f, corner, corner, texW, texH);
        blitRegion(g, tex, x, y + h - corner, corner, corner, 0f, h - corner, corner, corner, texW, texH);
        blitRegion(g, tex, x + w - corner, y + h - corner, corner, corner, w - corner, h - corner, corner, corner, texW, texH);

        // Edges
        blitRegion(g, tex, x + corner, y, midW, corner, corner, 0f, midW, corner, texW, texH);
        blitRegion(g, tex, x + corner, y + h - corner, midW, corner, corner, h - corner, midW, corner, texW, texH);
        blitRegion(g, tex, x, y + corner, corner, midH, 0f, corner, corner, midH, texW, texH);
        blitRegion(g, tex, x + w - corner, y + corner, corner, midH, w - corner, corner, corner, midH, texW, texH);

        // Center
        blitRegion(g, tex, x + corner, y + corner, midW, midH, corner, corner, midW, midH, texW, texH);
    }

    private static void blitRegion(GuiGraphicsExtractor g, Identifier tex,
                                   int x, int y, int w, int h,
                                   float u, float v, float regionW, float regionH,
                                   int texW, int texH) {
        if (w <= 0 || h <= 0) return;
        float u1 = u / texW;
        float u2 = (u + regionW) / texW;
        float v1 = v / texH;
        float v2 = (v + regionH) / texH;
        //? if >=1.21.6 {
        g.blit(tex, x, y, x + w, y + h, u1, u2, v1, v2);
        //?} elif >=1.21.2 {
        /*g.blit(net.minecraft.client.renderer.RenderType::guiTextured, tex, x, y, u, v, w, h, texW, texH);*/
        //?} else {
        /*g.blit(tex, x, y, u, v, w, h, texW, texH);*/
        //?}
    }
}
