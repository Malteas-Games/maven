package io.github.malteas.rosetta;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.Objects;

public class RosettaNotification {

    private final Identifier id;
    private final Component message;
    private Identifier icon;
    private int color = 0xFFFFFFFF;
    private boolean playSound = true;
    private Runnable onShow;
    private Component showLabel;

    public RosettaNotification(Identifier id, Component message) {
        this.id = Objects.requireNonNull(id);
        this.message = Objects.requireNonNull(message);
    }

    public RosettaNotification icon(Identifier icon) {
        this.icon = icon;
        return this;
    }

    public RosettaNotification color(int argb) {
        this.color = argb;
        return this;
    }

    public RosettaNotification noSound() {
        this.playSound = false;
        return this;
    }

    public RosettaNotification onShow(Component label, Runnable action) {
        this.showLabel = Objects.requireNonNull(label);
        this.onShow = Objects.requireNonNull(action);
        return this;
    }

    public Identifier id() { return id; }
    public Component message() { return message; }
    public Identifier icon() { return icon; }
    public int color() { return color; }
    public boolean playSound() { return playSound; }
    public Runnable onShow() { return onShow; }
    public Component showLabel() { return showLabel; }
    public boolean hasShowAction() { return onShow != null; }
}
