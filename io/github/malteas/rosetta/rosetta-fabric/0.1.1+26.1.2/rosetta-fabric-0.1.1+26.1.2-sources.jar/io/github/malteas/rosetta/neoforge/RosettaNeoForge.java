//? if neoforge {
/*
package io.github.malteas.rosetta.neoforge;

import io.github.malteas.rosetta.Rosetta;
import io.github.malteas.rosetta.RosettaKeys;
import io.github.malteas.rosetta.ui.NotificationHud;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod("rosetta")
public class RosettaNeoForge {
    public RosettaNeoForge(IEventBus modEventBus, ModContainer modContainer) {
        if (FMLEnvironment.getDist() == Dist.CLIENT) {
            NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post event) -> {
                Rosetta.drainPending();
                if (RosettaKeys.NOTIFICATIONS.consumeClick()) {
                    Rosetta.openNotificationScreen();
                }
            });
            NeoForge.EVENT_BUS.addListener((RegisterClientCommandsEvent event) ->
                    RosettaCommands.register(event.getDispatcher(), event.getBuildContext()));
            NeoForge.EVENT_BUS.addListener((RenderGuiEvent.Post event) ->
                    NotificationHud.draw(event.getGuiGraphics()));
            modEventBus.addListener((RegisterKeyMappingsEvent event) ->
                    event.register(RosettaKeys.NOTIFICATIONS));
        }
    }
}
*///?}
