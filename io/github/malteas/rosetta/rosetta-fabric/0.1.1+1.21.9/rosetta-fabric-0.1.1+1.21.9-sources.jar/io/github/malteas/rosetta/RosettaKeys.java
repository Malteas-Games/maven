package io.github.malteas.rosetta;

import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public final class RosettaKeys {

    //? if >=1.21.9 {
    private static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(
            class_2960.method_60655("rosetta", "keys")
    );

    public static final class_304 NOTIFICATIONS = new class_304(
            "key.rosetta.notifications",
            class_3675.field_32028,
            CATEGORY
    );
    //?} else {
    /*public static final KeyMapping NOTIFICATIONS = new KeyMapping(
            "key.rosetta.notifications",
            InputConstants.KEY_N,
            "key.categories.rosetta"
    );*/
    //?}

    private RosettaKeys() {}
}
