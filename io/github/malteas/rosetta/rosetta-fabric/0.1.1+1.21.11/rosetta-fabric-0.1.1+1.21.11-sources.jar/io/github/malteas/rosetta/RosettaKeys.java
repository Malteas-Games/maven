package io.github.malteas.rosetta;

import io.github.malteas.maltcore.client.MaltKeys;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public final class RosettaKeys {

    public static final class_304 NOTIFICATIONS = MaltKeys.create(
            "key.rosetta.notifications",
            class_3675.field_32028,
            MaltKeys.category("rosetta", "keys", "key.categories.rosetta"));

    private RosettaKeys() {}
}
