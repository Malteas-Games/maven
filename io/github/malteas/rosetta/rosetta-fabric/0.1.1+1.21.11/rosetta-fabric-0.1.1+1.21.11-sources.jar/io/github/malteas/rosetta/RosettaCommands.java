package io.github.malteas.rosetta;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.malteas.maltcore.client.command.FeedbackSink;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

/**
 * The /rosetta client command tree, generic in the command-source type so one
 * definition serves both loaders (registered via ClientHooks.registerClientCommand).
 */
public final class RosettaCommands {

    private RosettaCommands() {}

    public static <S> LiteralArgumentBuilder<S> build(FeedbackSink<S> feedback) {
        return LiteralArgumentBuilder.<S>literal("rosetta")
            .then(LiteralArgumentBuilder.<S>literal("reset")
                .executes(ctx -> resetAll(ctx, feedback))
                .then(RequiredArgumentBuilder.<S, String>argument("id", StringArgumentType.greedyString())
                    .suggests(RosettaCommands::suggestCards)
                    .executes(ctx -> resetOne(ctx, feedback))))
            .then(LiteralArgumentBuilder.<S>literal("show")
                .then(RequiredArgumentBuilder.<S, String>argument("id", StringArgumentType.greedyString())
                    .suggests(RosettaCommands::suggestCards)
                    .executes(ctx -> show(ctx, feedback))))
            .then(LiteralArgumentBuilder.<S>literal("list")
                .executes(ctx -> list(ctx, feedback)))
            .then(LiteralArgumentBuilder.<S>literal("replay")
                .executes(ctx -> replay(ctx, feedback)));
    }

    private static <S> int resetAll(CommandContext<S> ctx, FeedbackSink<S> feedback) {
        Rosetta.forgetAll();
        feedback.success(ctx.getSource(), class_2561.method_43470("[rosetta] Reset all card state."));
        return 1;
    }

    private static <S> int resetOne(CommandContext<S> ctx, FeedbackSink<S> feedback) {
        class_2960 id = parseId(ctx, feedback);
        if (id == null) return 0;
        Rosetta.forget(id);
        feedback.success(ctx.getSource(), class_2561.method_43470("[rosetta] Reset " + id + "."));
        return 1;
    }

    private static <S> int show(CommandContext<S> ctx, FeedbackSink<S> feedback) {
        class_2960 id = parseId(ctx, feedback);
        if (id == null) return 0;
        if (Rosetta.get(id).isEmpty()) {
            feedback.error(ctx.getSource(), class_2561.method_43470("[rosetta] No card registered with id " + id));
            return 0;
        }
        Rosetta.defer(() -> Rosetta.show(id));
        return 1;
    }

    private static <S> int replay(CommandContext<S> ctx, FeedbackSink<S> feedback) {
        Rosetta.defer(Rosetta::openReplayScreen);
        return 1;
    }

    private static <S> int list(CommandContext<S> ctx, FeedbackSink<S> feedback) {
        var registered = Rosetta.registered();
        if (registered.isEmpty()) {
            feedback.success(ctx.getSource(), class_2561.method_43470("[rosetta] No cards registered."));
            return 1;
        }
        feedback.success(ctx.getSource(), class_2561.method_43470("[rosetta] Registered cards (" + registered.size() + "):"));
        for (class_2960 id : registered.keySet()) {
            String marker = Rosetta.isSeen(id) ? " [seen]" : "";
            feedback.success(ctx.getSource(), class_2561.method_43470("  - " + id + marker));
        }
        return 1;
    }

    private static <S> CompletableFuture<Suggestions> suggestCards(CommandContext<S> ctx, SuggestionsBuilder builder) {
        for (class_2960 id : Rosetta.registered().keySet()) {
            String s = id.toString();
            if (s.startsWith(builder.getRemaining()) || s.contains(builder.getRemaining())) {
                builder.suggest(s);
            }
        }
        return builder.buildFuture();
    }

    private static <S> class_2960 parseId(CommandContext<S> ctx, FeedbackSink<S> feedback) {
        String raw = StringArgumentType.getString(ctx, "id");
        class_2960 id = class_2960.method_12829(raw);
        if (id == null) {
            feedback.error(ctx.getSource(), class_2561.method_43470("[rosetta] Invalid identifier: " + raw));
        }
        return id;
    }
}
