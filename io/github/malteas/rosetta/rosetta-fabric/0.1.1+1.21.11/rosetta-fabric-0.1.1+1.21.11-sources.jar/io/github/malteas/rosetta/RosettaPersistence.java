package io.github.malteas.rosetta;

import io.github.malteas.maltcore.config.ConfigPersistence;
import io.github.malteas.maltcore.platform.Platform;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;

final class RosettaPersistence {

    private static final Logger LOGGER = LoggerFactory.getLogger("rosetta");
    private static RosettaPersistence instance;

    /**
     * Values are Object (not Integer) so a state file with junk entries still
     * loads: non-numeric values are simply never "seen" and unknown keys are
     * carried along untouched.
     */
    static final class StateData {
        Map<String, Object> seen = new HashMap<>();
    }

    private final ConfigPersistence<StateData> persistence =
            new ConfigPersistence<>("rosetta", "state.json", StateData.class, StateData::new);

    private RosettaPersistence() {
    }

    static RosettaPersistence get() {
        if (instance == null) {
            instance = new RosettaPersistence();
            instance.persistence.init(Platform.configDir());
            instance.normalize();
        }
        return instance;
    }

    // Test seam: creates a persistence instance backed by an arbitrary path.
    static RosettaPersistence createForTesting(Path path) {
        RosettaPersistence p = new RosettaPersistence();
        p.persistence.initAtFile(path);
        p.normalize();
        return p;
    }

    // Test seam: overrides the singleton so tests don't touch the real config dir.
    static void setInstanceForTesting(RosettaPersistence p) {
        instance = p;
    }

    private Map<String, Object> seen() {
        StateData data = persistence.get();
        if (data.seen == null) {
            data.seen = new HashMap<>();
        }
        return data.seen;
    }

    /** Gson loads JSON numbers as Double; store them back as ints so saves stay clean. */
    private void normalize() {
        seen().replaceAll((k, v) -> v instanceof Number n ? n.intValue() : v);
    }

    boolean isSeen(class_2960 id, int version) {
        return seen().get(id.toString()) instanceof Number stored && stored.intValue() >= version;
    }

    void markSeen(class_2960 id, int version) {
        String key = id.toString();
        if (seen().get(key) instanceof Number stored && stored.intValue() >= version) return;
        seen().put(key, version);
        persistence.saveQuietly(LOGGER);
    }

    void forget(class_2960 id) {
        if (seen().remove(id.toString()) != null) {
            persistence.saveQuietly(LOGGER);
        }
    }

    void forgetAll() {
        if (seen().isEmpty()) return;
        seen().clear();
        persistence.saveQuietly(LOGGER);
    }
}
