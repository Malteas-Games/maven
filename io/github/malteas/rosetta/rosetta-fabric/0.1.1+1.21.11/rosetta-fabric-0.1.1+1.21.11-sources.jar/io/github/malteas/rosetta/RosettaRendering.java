package io.github.malteas.rosetta;

import io.github.malteas.maltcore.client.render.GuiDraw;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public final class RosettaRendering {

    private RosettaRendering() {}

    public static void renderTexture(class_332 g, class_2960 tex, int x, int y, int w, int h) {
        GuiDraw.texture(g, tex, x, y, w, h);
    }
}
