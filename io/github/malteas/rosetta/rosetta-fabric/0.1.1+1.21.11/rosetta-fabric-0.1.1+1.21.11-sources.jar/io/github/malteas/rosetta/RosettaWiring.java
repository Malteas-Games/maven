package io.github.malteas.rosetta;

import io.github.malteas.maltcore.client.ClientHooks;
import io.github.malteas.maltcore.client.MaltKeys;
import io.github.malteas.rosetta.ui.NotificationHud;
import net.minecraft.class_2960;

/**
 * All client wiring, shared by both loader entrypoints. Must run during client
 * init (Fabric) / mod construction (NeoForge) so keybinding registration lands
 * inside malt-core's queue window.
 */
public final class RosettaWiring {

    private RosettaWiring() {}

    public static void initClient() {
        MaltKeys.register(RosettaKeys.NOTIFICATIONS);

        ClientHooks.onEndClientTick(() -> {
            Rosetta.drainPending();
            if (RosettaKeys.NOTIFICATIONS.method_1436()) {
                Rosetta.openNotificationScreen();
            }
        });

        ClientHooks.addHudLayer(class_2960.method_60655("rosetta", "notifications"),
                (graphics, partialTick) -> NotificationHud.draw(graphics));

        ClientHooks.registerClientCommand(RosettaCommands::build);
    }
}
