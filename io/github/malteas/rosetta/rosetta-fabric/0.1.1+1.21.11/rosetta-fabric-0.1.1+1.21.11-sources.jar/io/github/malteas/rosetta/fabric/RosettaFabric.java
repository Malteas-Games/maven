//? if fabric {
package io.github.malteas.rosetta.fabric;

import io.github.malteas.rosetta.RosettaWiring;
import net.fabricmc.api.ClientModInitializer;

public class RosettaFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        RosettaWiring.initClient();
    }
}
//?}
