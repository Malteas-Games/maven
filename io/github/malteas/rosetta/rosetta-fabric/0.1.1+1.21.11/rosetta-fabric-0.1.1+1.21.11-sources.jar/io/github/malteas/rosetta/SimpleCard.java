package io.github.malteas.rosetta;

import io.github.malteas.rosetta.trigger.RosettaTrigger;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;

public class SimpleCard implements RosettaOnboardCard {

    private static final int TITLE_ICON_SIZE = 16;
    private static final int TITLE_ICON_GAP = 4;
    private static final float TITLE_SCALE = 1.5f;
    private static final int TITLE_HEIGHT = (int)(9 * TITLE_SCALE);
    private static final int TITLE_BOTTOM_GAP = 8;
    private static final int LINE_HEIGHT = 9;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 4;
    private static final int BUTTON_TOP_GAP = 8;

    private static final int SEP_PADDING = 4;
    private static final int SEP_HEIGHT = 1;
    private static final int SEP_COLOR = 0xFF555555;

    private static final int TITLE_COLOR = 0xFFFFFF00;
    private static final int TEXT_COLOR = 0xFFFFFFFF;

    private final class_2960 id;
    private final class_2561 title;
    private final CardCategory category;
    private final RosettaTrigger trigger;

    private class_2960 icon;
    private class_2960 background;
    private final List<ContentItem> content = new ArrayList<>();

    private sealed interface ContentItem {}
    private record TextItem(class_2561 message) implements ContentItem {}
    private record SeparatorItem() implements ContentItem {}
    private int version = 1;
    private int cardWidth = 300;
    private int overlayColor = 0x80000000;
    private CardBorder border;
    private boolean audio = true;
    private final List<CardButton> buttons = new ArrayList<>();

    private record CardButton(class_2561 label, Runnable onClick) {}

    public SimpleCard(class_2960 id, class_2561 title, CardCategory category, RosettaTrigger trigger) {
        this.id = Objects.requireNonNull(id, "SimpleCard.id must not be null");
        this.title = Objects.requireNonNull(title, "SimpleCard.title must not be null");
        this.category = Objects.requireNonNull(category, "SimpleCard.category must not be null");
        this.trigger = trigger;
    }

    public SimpleCard addIcon(class_2960 icon) {
        this.icon = Objects.requireNonNull(icon, "icon must not be null");
        return this;
    }

    public SimpleCard addBackground(class_2960 background) {
        this.background = Objects.requireNonNull(background, "background must not be null");
        return this;
    }

    public SimpleCard addText(class_2561 text) {
        this.content.add(new TextItem(Objects.requireNonNull(text, "text must not be null")));
        return this;
    }

    public SimpleCard addSep() {
        this.content.add(new SeparatorItem());
        return this;
    }

    public SimpleCard addButton(class_2561 label, Runnable onClick) {
        this.buttons.add(new CardButton(
                Objects.requireNonNull(label, "label must not be null"),
                Objects.requireNonNull(onClick, "onClick must not be null")));
        return this;
    }

    public SimpleCard version(int version) {
        this.version = version;
        return this;
    }

    public SimpleCard width(int width) {
        this.cardWidth = width;
        return this;
    }

    public SimpleCard overlay(int argbColor) {
        this.overlayColor = argbColor;
        return this;
    }

    public SimpleCard border(CardBorder border) {
        this.border = border;
        return this;
    }

    public SimpleCard noSound() {
        this.audio = false;
        return this;
    }

    @Override
    public boolean playAudio() {
        return audio;
    }

    @Override
    public int measureWidth() {
        return cardWidth;
    }

    @Override public class_2960 id() { return id; }
    @Override public class_2561 title() { return title; }
    @Override public CardCategory category() { return category; }
    @Override public RosettaTrigger trigger() { return trigger; }
    @Override public int version() { return version; }
    @Override public class_2960 icon() { return icon; }

    @Override
    public int measureHeight(class_327 font, int contentWidth) {
        int h = 0;
        int titleH = icon != null ? Math.max(TITLE_ICON_SIZE, TITLE_HEIGHT) : TITLE_HEIGHT;
        h += titleH + TITLE_BOTTOM_GAP;
        for (ContentItem item : content) {
            switch (item) {
                case TextItem t -> h += font.method_1728(t.message(), contentWidth).size() * LINE_HEIGHT;
                case SeparatorItem ignored -> h += SEP_PADDING + SEP_HEIGHT + SEP_PADDING;
            }
        }
        if (!buttons.isEmpty()) {
            h += BUTTON_TOP_GAP;
            h += buttons.size() * BUTTON_HEIGHT + (buttons.size() - 1) * BUTTON_GAP;
        }
        return h;
    }

    @Override
    public void drawBackground(class_332 graphics, int left, int top, int width, int height) {
        if (background != null) {
            RosettaRendering.renderTexture(graphics, background, left, top, width, height);
        }
        graphics.method_25294(left, top, left + width, top + height, overlayColor);
        if (border != null) {
            border.draw(graphics, left, top, width, height);
        }
    }

    @Override
    public void drawContent(class_332 graphics, class_327 font, int left, int top, int width, int height) {
        int y = top;
        int centerX = left + width / 2;

        int scaledTitleWidth = (int)(font.method_27525(title) * TITLE_SCALE);
        int titleH;

        if (icon != null) {
            int totalWidth = TITLE_ICON_SIZE + TITLE_ICON_GAP + scaledTitleWidth;
            int startX = centerX - totalWidth / 2;
            int iconY = y + (TITLE_HEIGHT - TITLE_ICON_SIZE) / 2 - 3;
            RosettaRendering.renderTexture(graphics, icon, startX, iconY, TITLE_ICON_SIZE, TITLE_ICON_SIZE);
            int textX = startX + TITLE_ICON_SIZE + TITLE_ICON_GAP;
            drawScaledString(graphics, font, title, textX, y, TITLE_COLOR);
            titleH = Math.max(TITLE_ICON_SIZE, TITLE_HEIGHT);
        } else {
            drawScaledCenteredString(graphics, font, title, centerX, y, TITLE_COLOR);
            titleH = TITLE_HEIGHT;
        }

        y += titleH + TITLE_BOTTOM_GAP;

        for (ContentItem item : content) {
            switch (item) {
                case TextItem t -> {
                    int lines = font.method_1728(t.message(), width).size();
                    graphics.method_65179(font, t.message(), left, y, width, TEXT_COLOR);
                    y += lines * LINE_HEIGHT;
                }
                case SeparatorItem ignored -> {
                    y += SEP_PADDING;
                    graphics.method_25294(left, y, left + width, y + SEP_HEIGHT, SEP_COLOR);
                    y += SEP_HEIGHT + SEP_PADDING;
                }
            }
        }
    }

    @Override
    public void addWidgets(Consumer<class_339> adder, class_327 font, int left, int top, int width, int height) {
        if (buttons.isEmpty()) return;

        int y = top + contentOffsetBeforeButtons(font, width);

        for (CardButton btn : buttons) {
            adder.accept(class_4185.method_46430(btn.label(), b -> btn.onClick().run())
                    .method_46433(left, y)
                    .method_46432(width)
                    .method_46431());
            y += BUTTON_HEIGHT + BUTTON_GAP;
        }
    }

    private void drawScaledString(class_332 g, class_327 font, class_2561 text, int x, int y, int color) {
        io.github.malteas.maltcore.client.render.GuiDraw.scaledText(g, font, text, x, y, TITLE_SCALE, color);
    }

    private void drawScaledCenteredString(class_332 g, class_327 font, class_2561 text, int cx, int y, int color) {
        io.github.malteas.maltcore.client.render.GuiDraw.scaledCenteredText(g, font, text, cx, y, TITLE_SCALE, color);
    }

    private int contentOffsetBeforeButtons(class_327 font, int contentWidth) {
        int y = 0;
        int titleH = icon != null ? Math.max(TITLE_ICON_SIZE, TITLE_HEIGHT) : TITLE_HEIGHT;
        y += titleH + TITLE_BOTTOM_GAP;
        for (ContentItem item : content) {
            switch (item) {
                case TextItem t -> y += font.method_1728(t.message(), contentWidth).size() * LINE_HEIGHT;
                case SeparatorItem ignored -> y += SEP_PADDING + SEP_HEIGHT + SEP_PADDING;
            }
        }
        y += BUTTON_TOP_GAP;
        return y;
    }
}
